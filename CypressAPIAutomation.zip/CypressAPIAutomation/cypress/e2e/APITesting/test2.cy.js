describe('Login form - Multiple sets of test data', () => {
    const testData = [
      { username: 'user1', password: 'password1', expectedMessage: 'Welcome, user1!' },
      { username: 'user2', password: 'password2', expectedMessage: 'Welcome, user2!' },
      { username: 'invalidUser', password: 'wrongPassword', expectedMessage: 'Invalid credentials' }
    ];
  
    // Iterate over the test data array
    testData.forEach(({ username, password, expectedMessage }) => {
      it(`should login with ${username}`, () => {

      });
    });
  });
  