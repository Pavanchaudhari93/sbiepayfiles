describe("BAsci auth", ()=>{
    it("Basic Auth",()=>{
        cy.request({
            method : "GET",
            url:"https://postman-echo.com/basic-auth",
            auth :{
                user:"postman",
                pass:"password"
            }
        }).then((response)=>{
            expect(response.status).to.eq(200)
            expect(response.body.authenticated).to.eq(true)
        })
    })

    it("Digest Auth",()=>{
        cy.request({
            method : "GET",
            url:"https://postman-echo.com/basic-auth",
            auth :{
                username:"postman",
                password:"password",
                method:"degest"
            }
        }).then((response)=>{
            expect(response.status).to.eq(200)
            expect(response.body.authenticated).to.eq(true)
        })
    })

    const token="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";
    it("bearer Auth",()=>{
        cy.request({
            method : "GET",
            url:"https://api.github.com/user/repos",
            headers :{
                Authorization:'Bearer '+token
            }
        }).then((response)=>{
            expect(response.status).to.eq(200)
        })
    })
})