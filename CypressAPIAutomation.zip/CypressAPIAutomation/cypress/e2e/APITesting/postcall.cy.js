describe("API TESTING", ()=>{
    it("APPROACH1- hard coaded json Object", ()=>{

        const requestBody = {
            title : "test post",
            body : "this is post call",
            userID : 2
        }

        cy.request({
            method : 'POST',
            url : 'https://jsonplaceholder.typicode.com/posts',
            body : requestBody
        }).then((response) => {
            expect(response.status).to.eq(201)
            expect(response.body.title).to.eq("test post")
            expect(response.body.body).to.eq("this is post call")
            expect(response.body.userID).to.eq(2)

        })
    })

    it("APPROACH2- dynamically generating jsonobjetc", ()=>{
        const requestBody = {
            title : Math.random().toString(5).substring(2),
            body : Math.random().toString(5).substring(2)+"gamil.com",
            userID : Math.random()
        }

        cy.request({
            method : 'POST',
            url : 'https://jsonplaceholder.typicode.com/posts',
            body : requestBody
        }).then((response) => {
            expect(response.status).to.eq(201)
            expect(response.body.title).to.eq(requestBody.title)
            expect(response.body.body).to.eq(requestBody.body)
            expect(response.body.userID).to.eq(requestBody.userID)

        })

    })


    it.only("APPROACH3- using fixture file", ()=>{
        cy.fixture('example').then((data) =>{
                const requestBody = data;

                cy.request({
                    method : 'POST',
                    url : 'https://jsonplaceholder.typicode.com/posts',
                    body : requestBody
                }).then((response) => {
                    expect(response.status).to.eq(201)
                    expect(response.body.title).to.eq(requestBody.title)
                    expect(response.body.body).to.eq(requestBody.body)
                    expect(response.body.userID).to.eq(requestBody.userID) 

                    expect(response.body).has.property('title',requestBody.title)
                    expect(response.body).has.property('body',requestBody.body)
                    expect(response.body).to.have.property('userID',requestBody.userID)
                })
            })
        })
})