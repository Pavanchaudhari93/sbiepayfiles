///<reference types='cypress'/>

import {productDetails} from '../../fixtures/refund copy.json';

describe("Refund API", ()=>{

    productDetails.forEach((items) => {
        it.only("APPROACH3- using fixture file invalid aggID", ()=>{
            // cy.fixture('refund copy').then((data) =>{
            //         const requestBody = data;
                    cy.request({
                        method : 'POST',
                        url : 'https://uat.sbiepay.sbi/payagg/RefundMISReport/refundEnquiryAPI',
                        form: true,
                        body : items
                     
                    }).then((response)=>{
                        expect(response.status).to.eq(200);
                        // cy.log('requestBody:'+requestBody)
                        expect(response.body).to.eq('ouu+sX89lh9XS5H98OP6LnWRJVBWFGdBlBujqfvyM2FmV9ox8z8QvmjdubuaxqC92Hap1MCw5Tz2\nWu28g/1YByuLV5ZyvuNxbhE4eLS/IBWm0khrm6k4bTRd1VEE/7GryTj6P+PsAqNeebR/NnM6F1iJ\nFZ9qFDISfseC1/VxGW4=');
                    // })
                })
            })
})
    // it("refundAPI",()=>{
    //     cy.request({
    //         method : "POST",
    //         url : "https://uat.sbiepay.sbi/payagg/RefundMISReport/refundEnquiryAPI",
    //         // Headers : {'content-type': 'application/x-www-form-urlencoded'}, instead use:-form: true,
    //         form: true,
    //         body : {
    //             "aggregatorId":"SBIEPAY",
    //             "merchantId":1000003,
    //             "queryRequest":"zDjRtS9nHgK730VphtNyWneNHP82bFbBbVb78YCI5y1rSjfMadRq7ko28HyM3m52"
    //         }
    //     }).then((response)=>{
    //         expect(response.status).to.eq(200);
    //         cy.log("response.body: "+response.body);
    //         expect(response.body).to.eq('ouu+sX89lh9XS5H98OP6LnWRJVBWFGdBlBujqfvyM2FmV9ox8z8QvmjdubuaxqC92Hap1MCw5Tz2\nWu28g/1YByuLV5ZyvuNxbhE4eLS/IBWm0khrm6k4bTRd1VEE/7GryTj6P+PsAqNeebR/NnM6F1iJ\nFZ9qFDISfseC1/VxGW4=');
    //     })
    // })
    
    // it("APPROACH3- using fixture file", ()=>{
    //     cy.fixture('refund copy').then((data) =>{
    //             const requestBody = data;

    //             cy.request({
    //                 method : 'POST',
    //                 url : 'https://uat.sbiepay.sbi/payagg/RefundMISReport/refundEnquiryAPI',
    //                 form: true,
    //                 body : {
    //                          "aggregatorId":data[0].aggregatorId,
    //                          "merchantId":data[0].merchantId,
    //                          "queryRequest":data[0].queryRequest
    //                         }
    //             }).then((response)=>{
    //                 expect(response.status).to.eq(200);
    //                 cy.log('requestBody:'+requestBody)
    //                 expect(response.body).to.eq('ouu+sX89lh9XS5H98OP6LnWRJVBWFGdBlBujqfvyM2FmV9ox8z8QvmjdubuaxqC92Hap1MCw5Tz2\nWu28g/1YByuLV5ZyvuNxbhE4eLS/IBWm0khrm6k4bTRd1VEE/7GryTj6P+PsAqNeebR/NnM6F1iJ\nFZ9qFDISfseC1/VxGW4=');
    //             })
    //         })
    //     })

    //     it("APPROACH3- using fixture file invalid MID", ()=>{
    //         cy.fixture('refund copy').then((data) =>{
    //                 const requestBody = data;
    
    //                 cy.request({
    //                     method : 'POST',
    //                     url : 'https://uat.sbiepay.sbi/payagg/RefundMISReport/refundEnquiryAPI',
    //                     form: true,
    //                     body : {
    //                              "aggregatorId":data[1].aggregatorId,
    //                              "merchantId":data[1].merchantId,
    //                              "queryRequest":data[1].queryRequest
    //                             }
    //                 }).then((response)=>{
    //                     expect(response.status).to.eq(200);
    //                     cy.log('requestBody:'+requestBody)
    //                     expect(response.body).to.eq('ouu+sX89lh9XS5H98OP6LnWRJVBWFGdBlBujqfvyM2FmV9ox8z8QvmjdubuaxqC92Hap1MCw5Tz2\nWu28g/1YByuLV5ZyvuNxbhE4eLS/IBWm0khrm6k4bTRd1VEE/7GryTj6P+PsAqNeebR/NnM6F1iJ\nFZ9qFDISfseC1/VxGW4=');
    //                 })
    //             })
    //         })

    //         it("APPROACH3- using fixture file invalid aggID", ()=>{
    //             cy.fixture('refund copy').then((data) =>{
    //                     const requestBody = data;
        
    //                     cy.request({
    //                         method : 'POST',
    //                         url : 'https://uat.sbiepay.sbi/payagg/RefundMISReport/refundEnquiryAPI',
    //                         form: true,
    //                         body : {
    //                                  "aggregatorId":data[2].aggregatorId,
    //                                  "merchantId":data[2].merchantId,
    //                                  "queryRequest":data[2].queryRequest
    //                                 }
    //                     }).then((response)=>{
    //                         expect(response.status).to.eq(200);
    //                         cy.log('requestBody:'+requestBody)
    //                         expect(response.body).to.eq('ouu+sX89lh9XS5H98OP6LnWRJVBWFGdBlBujqfvyM2FmV9ox8z8QvmjdubuaxqC92Hap1MCw5Tz2\nWu28g/1YByuLV5ZyvuNxbhE4eLS/IBWm0khrm6k4bTRd1VEE/7GryTj6P+PsAqNeebR/NnM6F1iJ\nFZ9qFDISfseC1/VxGW4=');
    //                     })
    //                 })
    //             })

                
});

