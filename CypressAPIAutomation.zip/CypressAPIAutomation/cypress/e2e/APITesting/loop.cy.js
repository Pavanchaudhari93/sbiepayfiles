///<reference types='cypress'/>

import {productDetails} from '../../fixtures/data.json';

describe("loading and accessing fixtures", ()=>{
    // beforeEach("visit page",()=> {
    //     cy.visit("https://www.examplewebsite.com/");
    // });
    productDetails.forEach((items) => {
    it("should access the data from the fixture", ()=> {
                productDetails.forEach((items) => {
                    cy.visit("https://www.examplewebsite.com/");
                    cy.get("#productname").clear().type(items.product);
                    cy.get("#categoryname").clear().type(items.category);
                })
        })
    });
});