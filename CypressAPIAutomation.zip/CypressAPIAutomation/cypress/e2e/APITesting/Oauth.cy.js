/*get access token oauth2.0
post https://github.com/login/oauth/access_token
query params :
        client_id
        client_secret
        CodeGen


        https://github.com/login/oauth/authorize?client_id=Ov23liTMoj3U1KRdITye
 2 send get req by using access token
    https://api.github.com/user/repos
*/

describe("Oauth2.0",()=>{
    let accessToken="";

        it(("get access token"),()=>{
            cy.request({
                method:"POST",
                url:"https://github.com/login/oauth/access_token",
                qs:{
                    client_id : "Ov23liTMoj3U1KRdITye",
                    client_secret:"19bdc9ab48dd13a5093de68651f67202057e2dac",
                    Code:"19caeeb6514f04220375"
                }
            }).then((response),()=>{
                 const params=response.body.split('&');
                 accessToken = params[0].split('=')[1];
            })

        })

        it("oauth 2 request",()=>{
            cy.request({
                method:"GET",
                url:"https://api.github.com/user/repos",
                headers:{
                    Authorization :'Bearer '+accessToken
                }
            }).then((response),()=>{
                expect(response.status).to.eq(200)
                cy.log('Generated access token '+accessToken);
                
            })
        })
})