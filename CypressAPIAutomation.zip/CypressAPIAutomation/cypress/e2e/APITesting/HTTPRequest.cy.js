describe("HTTPRequest", ()=>{

    it("Get call", ()=>{
        cy.request('GET','https://jsonplaceholder.typicode.com/posts/1')
        .its('status').should('equal',200);
    })

    it("post call", ()=>{
        cy.request({
            method : 'POST',
            url : 'https://jsonplaceholder.typicode.com/posts',
            body : {
                title : "test post",
                body : "this is post call",
                userID : 2

            }
        }).its('status').should('equal',201)
    })
})