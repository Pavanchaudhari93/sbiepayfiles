import { userDataProvider } from '../support/test-data-provider';
  
  describe('test section', () => {    
    userDataProvider.forEach((userData) => {
      it("description", () => {
        // expect(a + b).to.eq(expected);
        cy.log(userData);

      });
    });
  });