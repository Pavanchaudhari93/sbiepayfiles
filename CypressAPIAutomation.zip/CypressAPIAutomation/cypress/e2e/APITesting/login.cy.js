import{usreDataProvider} from '../../support/test-data-provider';

describe("log", ()=>{
    usreDataProvider.forEach((userData) => {
        it("logdinto", ()=>{
            cy.log(userData);
        });        
    });
})