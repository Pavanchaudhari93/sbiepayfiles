
describe('Login form - Multiple sets of test data', () => {
    it('should fetch data from the API', () => {

    cy.request('GET', 'https://dev.epay.sbi/transaction/v1/customer/Cust_kTq8pFbwHG59QgXf')
    .then((response) => {
      // Check that the response status code is 200 (OK)
      expect(response.status).to.eq(200);
      
      cy.log(response.body.data[1]); 
    })
    })

   
});
  