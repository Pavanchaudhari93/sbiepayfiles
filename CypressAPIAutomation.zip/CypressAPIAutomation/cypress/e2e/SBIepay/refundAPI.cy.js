describe("Refund API", ()=>{
    it("refundAPI",()=>{
        cy.request({
            method : "POST",
            url : "https://uat.sbiepay.sbi/payagg/RefundMISReport/refundEnquiryAPI",
            // Headers : {'content-type': 'application/x-www-form-urlencoded'}, instead use:-form: true,
            form: true,
            body : {
                "aggregatorId":"SBIEPAY",
                "merchantId":1000003,
                "queryRequest":"zDjRtS9nHgK730VphtNyWneNHP82bFbBbVb78YCI5y1rSjfMadRq7ko28HyM3m52"
            }
        }).then((response)=>{
            expect(response.status).to.eq(200);
            cy.log("response.body: "+response.body);
            expect(response.body).to.eq('ouu+sX89lh9XS5H98OP6LnWRJVBWFGdBlBujqfvyM2FmV9ox8z8QvmjdubuaxqC92Hap1MCw5Tz2\nWu28g/1YByuLV5ZyvuNxbhE4eLS/IBWm0khrm6k4bTRd1VEE/7GryTj6P+PsAqNeebR/NnM6F1iJ\nFZ9qFDISfseC1/VxGW4=');
        })
    })
    
    it.only("APPROACH3- using fixture file", ()=>{
        cy.fixture('refund').then((data) =>{
                const requestBody = data;

                cy.request({
                    method : 'POST',
                    url : 'https://uat.sbiepay.sbi/payagg/RefundMISReport/refundEnquiryAPI',
                    form: true,
                    body : 
                    requestBody
                }).then((response)=>{
                    expect(response.status).to.eq(200);
                    cy.log('requestBody:'+requestBody)
                    expect(response.body).to.eq('ouu+sX89lh9XS5H98OP6LnWRJVBWFGdBlBujqfvyM2FmV9ox8z8QvmjdubuaxqC92Hap1MCw5Tz2\nWu28g/1YByuLV5ZyvuNxbhE4eLS/IBWm0khrm6k4bTRd1VEE/7GryTj6P+PsAqNeebR/NnM6F1iJ\nFZ9qFDISfseC1/VxGW4=');
                })
            })
        })
})

