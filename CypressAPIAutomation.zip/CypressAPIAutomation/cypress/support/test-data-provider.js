import{testDataProvider} from './index';

export const userDataProvider = testDataProvider('users');