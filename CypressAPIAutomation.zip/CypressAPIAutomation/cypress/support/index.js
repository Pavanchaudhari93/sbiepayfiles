import { testData } from 'cypress-test-data-provider';

const testDataProvider = testData({
    users : [
        {
          "a": 0,
          "b": 1,
          "expected": 1,
        },
        {
          "a": 1,
          "b": 2,
          "expected": 3,
        },
      ],
});



