var keys;

//var isValidBranchAPI=true;
$(document).ready(function() {
	getKeys();
	$("#merchantName").prop("disabled", true);
	$("#merchantId").prop("readonly", true);
	$("#aggMIFModifyDetails").validate({
		ignore: [],
		rules : {
			merchantId : {
				required : true
			}
		},
		messages : {
			merchantId : {
				required : "Merchant Id is required"
			}
		},
		errorElement : "div"
	});
//ADDED BY POOJA PATIL
$("#panNumber").blur(function(){
	  var pan = $('#panNumber').val();
	  var regex="[A-Z]{5}[0-9]{4}[A-Z]{1}"


	   if (pan.match(regex)) {
		    if(pan.length != 10){
			 document.getElementById("panNumberError").innerHTML = "PAN Number should be 10 Digit";
			
			}else{
			 document.getElementById("panNumberError").innerHTML = "";
		    }
	   }else{
		   if(pan == ""){
			   			  document.getElementById("panNumberError").innerHTML = "";

	   }else{
			  document.getElementById("panNumberError").innerHTML = "Please Enter Valid PAN Number";
	   }
		  }


});

// added by nikhil 15 July 2024 start 

$('#websiteTechnology').blur(function(){

	if($('#websiteTechnology').val() == "Select"){
		document.getElementById("technologyError").innerHTML = "Please select web technology";  
		 return false;
	}
	else{
		document.getElementById("technologyError").innerHTML = "";  
		 return true;
	}

	});


$('#technologyVersion').blur(function(){

	if($('#technologyVersion').val() == "Select"){
		document.getElementById("technologyVersionError").innerHTML = "Please select web technology version";  
		 return false;
	}
	else{
		document.getElementById("technologyVersionError").innerHTML = "";  
		 return true;
	}

	});

// added by nikhil 15 July 2024 end 


	$("#gstnNumber").keyup(function(){

	var gstn = $('#gstnNumber').val().toUpperCase();
      $('#gstnNumber').val(gstn);

	});
	//Parag Davkhar
$("#stateName").change(function(){
		alert($("#encStatName1").val());
		var filed = $("#stateName").val();
		alert("state::"+filed);
		jQuery.ajax({
			type : "POST",
			dataType : 'xml',
			url : "aggMIFDropDown1.jsp?stateId="+filed,
			success : function(xml) 
			{
			
			var formOptions = "";
			$(xml).find("stateName").each(function(){
				$(this).find("option").each(function()
			        	{
				        		formOptions=formOptions+'<option value="'+$(this).attr("value")+'">'+$(this).text()+'</option>';
			        	});
			         	})
	    	   $('#cityName').html(formOptions);
			},
			error: function(ts) {
				alert(ts.responseText) }
		});

	});
	/////////////////CODE FOR PIN////////////////////////
	$("#cityName").change(function(){
		var filed=document.getElementById("cityName").value;
		alert(filed);
		$.ajax({
			type : "POST",
			dataType : 'xml',
			url : "aggMIFDropDown1.jsp?cityId="+filed,
			success : function(xml) 
			{ 
			var formLabel = "";
			$(xml).find("cityName").each(function(){
				$(this).find("label").each(function()
			        	{
					formLabel=$(this).text();
			        	});
			         	});	 /* alert(formLabel); */ 
	    	   
			   $('#pinCode').html(formLabel);
			   formLabel=$.trim(formLabel);
			   $('#pinCodeVal').val(formLabel);
			   if($.trim($("#pinCodeVal").val())!="")
					$("[for='pinCodeVal']").hide();
			}
		});
	});
	
	$("#isreturnrefundpolicyonsite").change(function()
			{
				if($.trim($("#isreturnrefundpolicyonsite").val())=="Y")
				{
					$("#returnrefundpolicylink").prop("disabled",false);
					$("#returnrefundpolicylink").rules("add", "required");
				}
				else
				{
					$("#returnrefundpolicylink").prop("disabled",true);
					$("#returnrefundpolicylink").rules("remove", "required");
				}
			});

	$('#noofattemptsyes').on("click",function(){
		
		 val = $('input[name=noofattempts]:checked').val();
		  
		 checkAttempts(val,"afterload");
		});


	$('#noofattemptsone').on("click",function(){
		
		 val = $('input[name=noofattempts]:checked').val();
		  
		 checkAttempts(val,"afterload");
		});
	

	$('#formModifyDetails').validate({    	
			rules : 
			{				
			    emailFirst :{email : true},
			    merchantlogourl: { required:true ,complete_url: true},
			    merchantmobilepagelogourl: { complete_url: true},
			    //panNumber :{required : false, panCheck :true },//added by pooja patil
			    firstName                   :   { lettersonly : true ,required:true, notWatermarkFirstName: true   },	
				middleName                  :   { lettersonly : true },
				lastName                    :   { lettersonly : true ,required:true, notWatermarkFirstName: true   },
				mobileNumber                :   { required : true, digits:true , minlength:10, maxlength: 10 },
				areaCodeLand                :   { required : true, notWatermarkPhoneArea   : true,  digits:true,     maxlength: 6, minlength:2 }, 
				phNumberLand                :   { required : true, notWatermarkPhoneNumber : true,  digits:true,     maxlength: 10, minlength:4 },
				areaCodeFax                 :   {   digits:true,     maxlength: 6, minlength:2 }, 
				phNumberFax                 :   {   digits:true,     maxlength: 10, minlength:4 },
			   	integrationType :  { required : true, check_item_dropdown : true },
			   	classification :  { required : true, check_item_dropdown : true },
			   	//moduleName :  { required : true, check_item_dropdown : true },
		        serverurl:{check_url:true},
		        webServicePostingURL:{webservice_url: true},
		        pushresponseUsername:{required:true,check_pushresponsefield:true},
		        pushresponsePassword:{required:true,passwordValidation:true},
		        pushresponseRepassword:{required:true, check_matchingpwd:true},
		        gstnNumber :{ gstnCheck :true },
		        businessName   :   { required: true , validateAll : true},
		        brandName   :   { required: true , validateAll : true},
		        validFrom   :   { required : true},
		        validTo   :   { required : true},
		        businessAddress   :   { required : true},
		        
                comemailid:{required:true, communicationemail:true},
				chargebacks  :   {required : true},   //Added by pooja for chargeback
				
			},
			messages : 
			{
			  merchantlogourl		: {required : "Merchant Logo URL required" },
			  //panNumber 			:{required : "Please enter valid pan number", panCheck :"Invalid pan number" },
			  firstName               :  { required : "Please enter contact person name" , lettersonly : "Letters Only" },
			  middleName              :  { lettersonly : "Letters Only" },
			  lastName                :  { required : "Please enter contact person name" , lettersonly : "Letters Only" },
			  mobileNumber            :  { required : "Please enter mobile number" , digits: "Invalid (digits only)" , minlength : "Minimum length should be 10 digit", maxlength : "Maximum length should be 10 digit"},
			  areaCodeLand            :  { required : "Please enter STD code and landline number" , digits : "Invalid (digits only)", minlength : "Minimum length should be 2 digit", maxlength : "Maximum length should be 6 digit"},
			  phNumberLand            :  { required : "Please enter STD code and landline number" , digits : "Invalid (digits only)" , minlength : "Minimum length should be 4 digit", maxlength : "Maximum length should be 10 digit"},
			  areaCodeFax            :  {  digits : "Please enter numbers only", minlength : "Minimum length should be 2 digit", maxlength : "Maximum length should be 6 digit"},
			  phNumberFax            :  {  digits : "Please enter numbers only" , minlength : "Minimum length should be 4 digit", maxlength : "Maximum length should be 10 digit"},
			  integrationType  	: { required : "Integration Type required" , check_item_dropdown : "Integration Type required" },
			   classification 		: { required : "Classification required" ,check_item_dropdown : "Classification required" },
			  // moduleName 			: { required : "Module Name required" ,check_item_dropdown : "Module Name required" },
			   //webServicePostingURL:{required : "Web Service Posting URL required" },
			   pushresponseUsername:{required:"Enter Push Response Username"},
			   pushresponsePassword:{required:"Enter Push Response Password"},
			   pushresponseRepassword:{required:"Enter Matching Password"},
			   validFrom:{required:"Please select valid from date"},
			   validTo:{required:"Please select valid To date"},
			   businessAddress:{required:"Please enter address"},
              comemailid :{required : "Please enter valid Communication Email ID", communicationemail :"Invalid Communication Email ID" },//added by priyanka
		      chargebacks: {required : "Chargeback IsApplicable Required"},   //Added by pooja for chargeback 
			
			},
			errorElement: "div",
			groups: 
			{
				 NameDetailsError:  " firstName middleName lastName  ",
				 emailLastError		: "emailFirst emailLast",
				 PhoneDetails    	:  "areaCodeLand phNumberLand",
				 phNumFaxErrorMsg : "areaCodeFax phNumberFax"
			
			},
			
				}); 
	
	$.validator.addMethod("complete_url", function(val, elem) {
	    if (val.length == 0) { return true; }
	 //return /^(https:\/\/){1}(www\.)?((?!www\.)[a-zA-Z0-9]*[\.\-]{0,1}[a-zA-Z0-9]+)+\.(com|org|net|mil|edu|in|COM|ORG|NET|MIL|EDU|IN|ac|AC|info|INFO|co|CO|sbi|SBI|online|ONLINE)[\.]{0,1}(\/[a-zA-Z0-9_]*[\.\-]{0,1}[a-zA-Z0-9_]+)+\.(JPG|jpg|TIFF|tiff|GIF|gif|BMP|bmp|PNG|png|JPEG|jpeg|JFIF|jfif|IMG|img){1}$/i.test(val);
	 return /^https:\/\/([\w\d\-]+\.)+\w{2,}(\/.+)?$/i.test(val);
	},"Please enter valid Logo URL. https:// is mandatory.");

	 $.validator.addMethod("panCheck", function(value, element) 
	    		{ 
	    	return this.optional(element) || /^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$/i.test(value);
	     		}, "Invalid pan number"); 
	 
	$.validator.addMethod("gstnCheck", function(value, element) 
				{ 
		    return this.optional(element) || /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/i.test(value);
           //  return this.optional(element) || /([0-9]){2}([A-Z]){4}([A-Z]||[0-9]){1}([0-9]){4}([A-Z]){1}([0-9]){1}([A-Z]){1}([A-Z]||[0-9]){1}$/i.test(value);    commented by Anuradha
		  
		 		}, "Invalid GSTIN"); 
	
	 $.validator.addMethod("notWatermarkFirstName",function(value, element)
    {
       return value != '' ; 
   },"Please enter contact person name"); 
	 
	 $.validator.addMethod("lettersonly", function(value, element) 
			   { 
	 	    	return this.optional(element) || /^[a-zA-Z\s]*$/i.test(value);
	 		   }, "Letters Only");
	 
	 $.validator.addMethod("email", function(value, element)
				{ 
			    var emailId=$('#emailFirst').val()+"@"+$('#emailLast').val();
			    if(emailId!=""+"@"+""){
			    return /^[a-zA-Z0-9._-]+@[A-Za-z0-9-]+(.[A-Za-z0-9]+)*(.[A-Za-z]{2,5})$/i.test(emailId);}
			    else{
			    	return true;
			    }
				}, "Please enter a valid email address");
	 
   
	 //added for communication email id
	 $.validator.addMethod("communicationemail",function(value, element)
		     {
		 return this.optional(element) || /^[a-zA-Z0-9._-]+@[A-Za-z0-9-]+(.[A-Za-z0-9]+)*(.[A-Za-z]{2,5})$/i.test(value);
		    },"Invalid Communication Email ID"); 

	 $.validator.addMethod("notWatermarkPhoneArea",function(value, element)
     {
        return value != 'STD Code' ; 
    },"Please enter STD code and landline number"); 
   
	    $.validator.addMethod("notWatermarkPhoneNumber",function(value, element)
     {
        return value != 'Phone No.' ; 
    },"Please enter STD code and landline number"); 
	    
	    $.validator.addMethod("check_item_dropdown", function(value, element) {
	    	return this.optional(element)|| $.trim(value) != "";
	    }, "required");
	    

	    $.validator.addMethod("check_url", function(value, element)
	    		{ 
	    			var url=$('#serverurl').val();
	    			if(document.getElementById("flag").checked == true)
	    			{
	    			
	    				if($('#serverurl').val()==null || $('#serverurl').val()=="" )
	    				{
	    					return false;
	    				}
	    				
	    				else{
	    					/*return /^(https:\/\/.)?(www\.)?[-a-zA-Z0-9._\@+]{2,256}\.(com|org|net|mil|edu|in|COM|ORG|NET|MIL|EDU|IN|ac|AC|info|INFO|co|CO])\b([-a-zA-Z0-9@:%_\+.~#?&]*)/i.test(url);*/
	    					/*return /^(https:\/\/){1}(www\.)?((?!www\.)[a-zA-Z0-9]*[\.\-]{0,1}[a-zA-Z0-9]+)+\.(com|org|net|mil|edu|in|COM|ORG|NET|MIL|EDU|IN|ac|AC|info|INFO|co|CO])\b([-a-zA-Z0-9@:%_\+.~#?&]*)/i.test(url);*/
	    					//return /^(https:\/\/){1}(www\.)?([a-zA-Z0-9]*[\.\-]{0,1}[a-zA-Z0-9]+)+\.(aero|aai|com|org|net|mil|edu|in|COM|ORG|NET|MIL|EDU|IN|ac|AC|info|INFO|co|CO|sbi|SBI|online|ONLINE])\b([-a-zA-Z0-9@:%_\+.~#?&]*)/i.test(url);
	    				 return /^https:\/\/([\w\d\-]+\.)+\w{2,}(\/.+)?$/i.test(url);
	    				}
	    				
	    			}	
	    				else {
	    					if($('#serverurl').val()==null || $('#serverurl').val()=="" )
		    				{
		    					return true;
		    				}
	    					else{
	    					/*return /^(https:\/\/.)?(www\.)?[-a-zA-Z0-9._\@+]{2,256}\.(com|org|net|mil|edu|in|COM|ORG|NET|MIL|EDU|IN|ac|AC|info|INFO|co|CO])\b([-a-zA-Z0-9@:%_\+.~#?&]*)/i.test(url);*/
	    					/*return /^(https:\/\/){1}(www\.)?((?!www\.)[a-zA-Z0-9]*[\.\-]{0,1}[a-zA-Z0-9]+)+\.(com|org|net|mil|edu|in|COM|ORG|NET|MIL|EDU|IN|ac|AC|info|INFO|co|CO])\b([-a-zA-Z0-9@:%_\+.~#?&]*)/i.test(url);*/
	    					//return /^(https:\/\/){1}(www\.)?([a-zA-Z0-9]*[\.\-]{0,1}[a-zA-Z0-9]+)+\.(aero|aai|com|org|net|mil|edu|in|COM|ORG|NET|MIL|EDU|IN|ac|AC|info|INFO|co|CO|sbi|SBI|online|ONLINE])\b([-a-zA-Z0-9@:%_\+.~#?&]*)/i.test(url);
	    				 return /^https:\/\/([\w\d\-]+\.)+\w{2,}(\/.+)?$/i.test(url);
	    				}
	    				}
	    			
	    		},"Please enter valid Push Response URL. https:// is mandatory.");

	    $.validator.addMethod("check_pushresponsefield", function(value, element) {
	    	return this.optional(element)|| $.trim(value) != "" ;		
	    }, "required");
	    

	    $.validator.addMethod("check_matchingpwd", function(value, element) {
	    	var newPassword=$('#pushresponsePassword').val();
	    	var pushresponseRepassword=$('#pushresponseRepassword').val();
	    	if(newPassword!=pushresponseRepassword){
	    		return false;
	    	}else{
	    		return true;
	    	}
	    	
	    },"Enter Matching Password");

	    $.validator.addMethod("passwordValidation", function(value, element) {
	    	var newPassword=$('#pushresponsePassword').val();

	    	var specialChars=/[\x20|\x5F|\x2D|\x40|\x2F|\x3A|\x2C]+/g;

	    	if((newPassword.length>0 && newPassword.length<8) || specialChars.test(newPassword)){
	    		return false;
	    	}else{
	    		return true;
	    	}
	    	
	    },"Must contain alphanumeric minimum 8 length character");
	    
	    $.validator.addMethod("webservice_url", function(val, elem) {
	        if (val.length == 0) { return true; }
	     //return/^(https:\/\/.)?(www\.)?[-a-zA-Z0-9._\@+]{2,256}\.(com|org|net|mil|edu|in|COM|ORG|NET|MIL|EDU|IN|ac|AC|info|INFO|co|CO|sbi|SBI|online|ONLINE])\b([-a-zA-Z0-9@:%_\+.~#?&]*)/i.test(val);
		 return /^https:\/\/([\w\d\-]+\.)+\w{2,}(\/.+)?$/i.test(val);
	    },"Please enter valid Web Service Posting URL. https:// is mandatory.");
	    
	    /***ADDED BY AQUEEL*******/
	    $.validator.addMethod("noSpecialChar", function(value, element) {
	         return  this.optional(element) || /^[a-zA-Z]*$/.test(value); 
	       }, "Please do not enter special characters");
	    /************************/
		$.validator.addMethod("validateAll", function(value, element) {
                     return   /^[A-Za-z0-9\s`~!@#$%^*()+={}|;:",.<>\/?\\-]+$/i.test(value); 
                   }, "Please do not enter special character & and ' ");
	 $("#emailLast").blur(function(){
			$("#emailFirst").blur();
			});
	 $("#merchantId").change(function()
				{
		 $('#encMerchantId').val($('#merchantId').val());


	var c = $("#merchantId").val();
			var b = $("#aggregator").val();
					jQuery
			.ajax({
				type : "POST",
				dataType : "xml",
				url : "aggGetMerchantNameOnMerchantIdAjax.jsp",
				data : {
					param1 : c,
					param2 : b
				},
				async : false,
				success : function(d) {
					$(d)
							.find(
									"merchantsub")
							.each(
									function() {
										$(this)
												.find("input")
												.each(
														function() {
																
															$("#merchantName")
																	.val(
																			$(this)
																					.attr("value"))
														})
									})
				}
			})
		 


				});
	 
	 $("#search").click(function() {
		 if( $("#aggMIFModifyDetails").valid()){
		 $.jCryption.encrypt($('#merchantName').val(), keys, function(encMerchantName) {
			 $('#encMerchantName').val(encMerchantName);
				$.jCryption.encrypt($('#merchantId').val(), keys, function(encMerchantId) {
					$('#encMerchantId').val(encMerchantId);
					$.jCryption.encrypt($('#aggregator').val(), keys, function(encAggId) {
						$('#encAggId').val(encAggId);
						$.jCryption.encrypt($('#search').val(), keys, function(encSearch) {
							$('#encSearch').val(encSearch);
							
									$("#aggMIFModifyDetails").submit();
						
							
						});
					});
				});
		 });
		 }
		});
	
	   $('#branchCode1').on('keyup',function(){
		 
                var branchCode=$(this).val();

				  if(branchCode==""){
                  			document.getElementById("branchCodeError23").style.display = "none";
							$("branchCodeError23").text("");	
							$('#branchName').val("");
							$('#circleCodes').val("");
							$('#circleName').val("");

					return;
				}
                
                 //special char validation -23jan2024
				var numberRegex = /^\d+$/;
				if (branchCode != "" && !numberRegex.test(branchCode)) {
						 document.getElementById( 'branchCodeError23' ).style.display = 'none';
						 document.getElementById('branchCodeError23').style.display = 'block';
						 document.getElementById("branchCodeError23").innerHTML = "Enter Only Digit";
						 $("[for=branchCode1]").css("display", "none");
					
						return false;
				}

				
				var branchCodeLength = $("#branchCode1").val().length;
                

                $('#branchCode1').prop("readonly",false);
                $('select[name="#branchCode1"]').empty();
				var loginId = $('#userId').val();
				var title = $('#title').val();
                if(branchCode != null ) {
	                 $.ajax({
	                  url: "aggMIFRegisterActionAjax.jsp",
	                  type: "GET",
	                  dataType: "json",
	                  data : {branchCode : branchCode,
							  loginId : loginId,
							  title : title
					},
	                  success: function(data){
	                  if(data != null){
							
						   if(data[1]=="Eis application in active" || data[1]== 'REQUESTED PARAMETER RECORD DOESN T EXIST' ||
							   data[1]=="CONNECTION RESET BY CBS" || data[1]=="SI599|UNABLE TO PROCESS DUE TO TECHNICAL ERROR" ||
							   data[1]=="UNABLE TO PROCESS DUE TO TECHNICAL ERROR")
						  {
							    

								document.getElementById("branchCodeError23").innerHTML = "We can't find the entered Branch Code in our records,If sure continue with your input.";
							    document.getElementById("branchCodeError23").style.display = "block";
							
									
									var defaultBranchCode = $("#defaultBranchCode").val();
									var defaultBranchName = $("#defaultBranchName").val();
									var defaultCircleCode = $("#defaultCircleCode").val();
									var defaultCircleName = $("#defaultCircleName").val();
									defaultBranchCode = "";
									if ("" != defaultBranchCode)
									{
										$("#branchCode1").val(defaultBranchCode);
										$("#branchName").val(defaultBranchName);
										$("#circleCodes").val(defaultCircleCode);
										$("#circleName").val(defaultCircleName);

									}else{

										
										$("#circleCodes").val("NA");
										

									}

						  }else{
	                	   
	  	                    $('#browsers').empty();

	  						if(branchCodeLength != 5){
	  							document.getElementById("branchCodeError23").style.display = "none";
								$("branchCodeError23").text("");	
	  							$('#branchName').val("");
	  							$('#circleCodes').val("");
	  							$('#circleName').val("");

	  							$.each(data,function(index,val){
	  	                   
	  	                    	$('#browsers').append('<option value="'+data[index]+'"> </option>');	
	  	                       
	  							});
	  							
	  						}else{

								document.getElementById("branchCodeError23").innerHTML = "";
								document.getElementById("branchCodeError23").style.display = "none";
	  								$('#branchName').val(data[0].replaceAll(/[^a-zA-Z0-9 ]/g," "));
	  					 			$('#circleCodes').val(data[1].replaceAll(/[^a-zA-Z0-9 ]/g," "));
	  								$('#circleName').val(data[7].replaceAll(/[^a-zA-Z0-9 ]/g," "));
	  						}
	                		  
	                	  }
	

					  }
	
	                  },
	                  
			            error: function (jqXHR, exception) {
			            	var msg = 'Error While Serving Request';
			          
			            },
	         
	                 });
                }
           });


});

function timeChecker(timeFlag,source)
{
	
	if(timeFlag == "Y")
	{
	    $("#timedisp").css("display","table-row");
	    $("#timeminute").css("display","block");
	    
	    var hiddenY=$("#hiddentimeminute").val();
		var timedisp = {};

		for(var j=5;j<=120;j++){
			timedisp[j]=j;
		}

				var $time = $("#timeminute");
				$time.empty(); // remove old options
				$.each(timedisp, function(value,key) {
				  $time.append($("<option></option>")
				     .attr("value", value).text(key));
				});

			if(source == "onload")
			$("#timeminute option[value=" + hiddenY +"]").attr("selected","selected");
		
	}
	else
	{
		$('#timeminute').empty();
		$("#timedisp").css("display","none");
		 $("#timeminute").css("display","none");
	}

}

function checkAttempts(noofattempts,source) {
	
	if(noofattempts == 'Y'){
			
		 var newOptions = {"1": "1",
				  "2": "2",
				  "3": "3"
				};

		for(var i=1;i<=99;i++){
			newOptions[i]=i;
		}

				var $el = $("#attemptsallowed");
				$el.empty(); // remove old options
				$.each(newOptions, function(value,key) {
				  $el.append($("<option></option>")
				     .attr("value", value).text(key));
				});
				var hiddenY=$("#hiddenattempts").val();
		 }else if(noofattempts == 'ONESUCCESS'){
				var oneSucesss = {"INFINITE": "INFINITE"};

			 	var $el = $("#attemptsallowed");
					$el.empty(); // remove old options
					$.each(oneSucesss, function(value,key) {
					  $el.append($("<option></option>")
					     .attr("value", value).text(key));
					}); 
					var hiddenY=$("#hiddenattempts").val();
		 }
	
	if(source == "onload")
	$("#attemptsallowed option[value=" + hiddenY +"]").attr("selected","selected");
		}


function webServiceChecker()
{
	if($('#moduleName').val()=="MERCHANTBANKACCOUNT")
	{
		
	    $("#webServicePostingURLLabel").css("display","table-row");
	    $("#webServicePostingURL").css("display","block");
	}
	else
	{
		$("#webServicePostingURL").val("");
		$("#webServicePostingURLLabel").css("display","none");
		 $("#webServicePostingURL").css("display","none");
	}

}
$(window).on('load' ,function(){ 
//$( window ).load(function() {
	var val = null;
	 if($('#noofattemptsyes').is(':checked')) {
		 
		  val = $('input[name=noofattempts]:checked').val();
		  
		 checkAttempts(val,"onload");
		}else if ($('#noofattemptsone').is(':checked')){
		  val = $('input[name=noofattempts]:checked').val();
		  
		 checkAttempts(val,"onload");
		}
	 
	 if($('#timeallowedyes').is(':checked')) {
		 
		  val = $('input[name=timeallowed]:checked').val();
		  
		  timeChecker(val,"onload");
		}else {
		  val = $('input[name=timeallowed]:checked').val();
		  
		  timeChecker(val,"onload");
		}
	 
	});

function disOther(a) {
	$("#merchantId").val("");
	$("#merchantName").val("");
	if (a === "merchName") {
		$("#merchantName").prop("disabled", false);
		$("#merchantId").prop("readonly", true);
		$("#merchantId").prop("disabled", false);
	} else {
		if (a === "merchId") {
			$("#merchantName").prop("disabled", true);
			$("#merchantId").prop("readonly", false);
			$("#merchantId").prop("disabled", false);
		}
	}

}
$().ready(function() {

	$("#merchantName").autocomplete({
		highlightClass: "bold-text",
		source: function (request, response) {
			$.ajax({
				url: "/secure/admin/aggMerchList.jsp",
				data : {
					"q" : $("#merchantName").val(),
				},
				dataType: "xml",
				type: "POST",
				success: function (data) {
					var data = $(data).find("DATA").text().trim().split("\n");
					response(data);
				}

			});
		},  

		select: function( event, ui ) {
			event.preventDefault();
			$("#merchantName").val(ui.item.value.split("|")[0]);
			$("#merchantId").val(ui.item.value.split("|")[1]);
			$("#encMerchantId").val(ui.item.value.split("|")[1]);
		},

		minLength: 1,
		delay: 0,
		width: 260,
		matchContains: true,
		mustMatch: true,
		cacheLength: 10,
		selectFirst: false,

	}).autocomplete( "instance" )._renderItem = function( ul, item ) {
		var regEx = new RegExp('(' + this.term + ')', "ig");
		var nameValPair = item.label.split("|");
		var la = nameValPair[0].replace(regEx,"<b>$1</b>")
		return $( "<li>" ).append( "<div>" + la + "</div>" ).appendTo( ul );
	};

});


$(document).ready(function() {
	var a = $("#merchButton").val();
	if (a === "Get Details") {
		$(".transferTypeId").hide();

		}
});

/*function diableRefund(){
	var check = $('#mutaccount:checked').val();
	alert("check="+check);
	if(check == 'Y'){
		
	}
	else if(check==undefined){		
		$("#isRefundSettle").append('<option value="Y">Yes</option>');
	}
	else{
		$("#isRefundSettle option[value='Y']").remove();
	}
}*/

function diableRefund(){
var check = $('#mutaccount:checked').val();
alert("check="+check);
if(check == 'Y'){
	$("#isreturnrefundpolicyonsite option[value='Y']").remove();
	$("#isreturnrefundpolicyonsite option[value='N']").remove();
	$("#isreturnrefundpolicyonsite").append('<option value="N">No</option>');
	$("#isreturnrefundpolicyonsite").append('<option value="Y">Yes</option>');
	$("#isRefundSettle").val("N");
	$("#refundSettle").hide();
}
else if(check==undefined){
	$("#isreturnrefundpolicyonsite option[value='Y']").remove();
	$("#isreturnrefundpolicyonsite option[value='N']").remove();
	$("#isreturnrefundpolicyonsite").append('<option value="N">No</option>');
	$("#isreturnrefundpolicyonsite").append('<option value="Y">Yes</option>');
	if($("#isreturnrefundpolicyonsite").val() == 'N'){
		$("#refundSettle").hide();
		$("#isRefundSettle").hide();
	}
	else{
	$("#refundSettle").show();
	$("#isRefundSettle").show();
	}
}
}

/*$(function () {
	 $('#mutaccount').click(function () {
	   var val = $(this).val();
	   alert(val);
	   if(val == 'Y'){
		   $("#isreturnrefundpolicyonsite").append("Yes");
	   }
	   else
		   {
		   $("#isreturnrefundpolicyonsite").append("No");
		   }

	  });
	});*/

function showOrHide()
{
	var isRefund=$("#isreturnrefundpolicyonsite").val();
	    if(isRefund=="Y")
		{	
			$("#refundSettle").show();
			$("#isRefundSettle").show();
		}
	    else if(isRefund=="N")
		{
	    	$("#isRefundSettle").val("N");
			$("#refundSettle").hide();	
		}
}

function serverCom()
{
	if($('#flag').is(":checked"))
	{
		
	  //  $('#serverurl').val('');
	    $("#urlserver").css("display","table-row");
	   $("#servereurl").css("display","none");
	    $("#pushresponseauthID").css("display","table-row");
	    $("#pushresponseauthN").attr('checked','checked');
	    
	}
	else
	{
		//$('#serverurl').val('');
		$("#urlserver").css("display","none");
	    $("#servereurl").css("display","none");
		$("#urlserver").css("display","table-row");
		 $("#pushresponseauthID").css("display","none");
		 $("#pushresponseauthForm").slideUp(); 
		 $('#pushresponseUsername').val(""); 
		 $("#pushresponsePassword").val("");
		 $("#pushresponseRepassword").val("");
		
	}
}
//Parag Davkhar added for checksum start
function checkSum()
{
	if($('#isCheckSumApplicable').is(":checked"))
	{
	    $("#checkurl").css("display","table-row");
	}
	else
	{
		$("#checkurl").css("display","none");
	}
}
//Parag Davkhar added for checksum end

setPushResponse=function (pushResponse)
{
	if(pushResponse == "Y")
	{
		$('#pushresponseUsername').val("");
		 $("#pushresponsePassword").val("");
		 $("#pushresponseRepassword").val("");
		$("#pushresponseauthForm").slideDown();	
	}
	if(pushResponse == "N")
	{
		 $('#pushresponseUsername').val("");
		 $("#pushresponsePassword").val("");
		 $("#pushresponseRepassword").val("");
		$("#pushresponseauthForm").slideUp();
	}
};


function setNext(){
	//added by pooja patil
	 //if(!isValidBranchAPI){
			 // return false;
	 //}

     var remarks = document.getElementById("branchCode1").value;
	// var remarks1 = document.getElementById("branchName").value;
	 document.getElementById('branchCodeError23').style.display = 'none';
	 document.getElementById("branchCodeError23").innerHTML = "";
	  
	

            //special char validation -23jan2024
				var numberRegex = /^\d+$/;
	if (remarks != "" && !numberRegex.test(remarks)) {
			document.getElementById( 'branchCodeError23' ).style.display = 'none';
			 document.getElementById('branchCodeError23').style.display = 'block';
			 document.getElementById("branchCodeError23").innerHTML = "Enter Digits Only";
			 $("[for=branchCode1]").css("display", "none");
			
		    return false;
	}

	if($('#websiteTechnology').val() == "Select"){
		document.getElementById("technologyError").innerHTML = "Please select web technology";  
		 return false;
	}
	
	
	if($('#technologyVersion').val() == "Select"){
		document.getElementById("technologyVersionError").innerHTML = "Please select web technology version";  
		 return false;
	}
	 var formValid= $("#formModifyDetails").valid();
	alert(formValid);
	 if(formValid){
	 var returnFlag = true;
		 
		 var merchantbusinessurl = $('#merchantbusinessurl').val().replace(/(?:\r\n|\r|\n)/g, '');
		 if(merchantbusinessurl == ""){
			 document.getElementById("merchantbusinessurlError").innerHTML = "Please enter business URL";  
			 return false;
		 }else{
		 var partsOfStr = merchantbusinessurl.split(',');
		 for(var i=0; i < partsOfStr.length; i++) {
			    var url = partsOfStr[i];
			    formValid = isUrlValid(url);
			    alert(formValid);
			    if(!formValid){
			    	document.getElementById("merchantbusinessurlError").innerHTML = "Please enter valid URL. https://domain.com"; 
			    	return false;
			break;
			    	}
		 		}
		 	}
		 }

		 if(formValid){
				var returnFlag = true;
				var pan = $('#panNumber').val();
	 
		$("#panNumberError").hide();
			var regex="[A-Z]{5}[0-9]{4}[A-Z]{1}"
	

			if (pan.match(regex)) {
				if(pan.length != 10){
				 document.getElementById("panNumberError").innerHTML = "PAN Number should be 10 Digit";
				 $("#panNumberError").show();
					return false;
				}else{
				 document.getElementById("panNumberError").innerHTML = "";
				}
			 }else{
			   if(pan == ""){
				 document.getElementById("panNumberError").innerHTML = "";
				

			 }else{
				  document.getElementById("panNumberError").innerHTML = "Please Enter Valid PAN Number";
				 $("#panNumberError").show();
				  return false;
				}
			}
		 }
		 
	 if(formValid)
		{
		    if (confirm("Changes in Merchant Registration will have impact on transactions. Are you sure you want to continue?")) {
		    	$('#bizUrl').val(merchantbusinessurl);
		    	
		    	   $('#bizUrl').val($.base64('encode', $('#bizUrl').val()).replace(/=/g, "equal"));
		    	   
		    	   $('#merchantlogourl').val($.base64('encode', $('#merchantlogourl').val()).replace(/=/g, "equal"));
		    	   
		    	   if($('#merchantmobilepagelogourl').val() != null && $('#merchantmobilepagelogourl').val() != '')
		    		   $('#merchantmobilepagelogourl').val($.base64('encode', $('#merchantmobilepagelogourl').val()).replace(/=/g, "equal"));
		    	   else
			    	  $('#merchantmobilepagelogourl').val('');
   
		    	   if($('#serverurl').val() != null && $('#serverurl').val() != '')
		    		   $('#serverurl').val($.base64('encode', $('#serverurl').val()).replace(/=/g, "equal"));
		    	   else
				    	  $('#serverurl').val('');
		    	   
		    	   if($('#webServicePostingURL').val() != null && $('#webServicePostingURL').val() != '')
		    		   	 $('#webServicePostingURL').val($.base64('encode', $('#webServicePostingURL').val()).replace(/=/g, "equal"));
		    	   else
				    	  $('#webServicePostingURL').val('');
		    	$.jCryption.encrypt($('#panNumber').val(), keys, function(panNumber) {
					 $('#panNumber').val(panNumber);
					 
					 $.jCryption.encrypt($('#firstName').val(), keys, function(firstName) {
						 $('#firstName').val(firstName);
						 
						 $.jCryption.encrypt($('#middleName').val(), keys, function(middleName) {
							 $('#middleName').val(middleName);
							 
							 $.jCryption.encrypt($('#lastName').val(), keys, function(lastName) {
								 $('#lastName').val(lastName);
								 
								 $.jCryption.encrypt($('#emailFirst').val(), keys, function(emailFirst) {
									 $('#emailFirst').val(emailFirst);
									 
									 $.jCryption.encrypt($('#emailLast').val(), keys, function(emailLast) {
										 $('#emailLast').val(emailLast);
										 $.jCryption.encrypt($('#comemailid').val(), keys, function(comemailid) {
											 $('#comemailid').val(comemailid);
											 $.jCryption.encrypt($('#mobileNumber').val(), keys, function(mobileNumber) {
												 $('#mobileNumber').val(mobileNumber);
												 $.jCryption.encrypt($('#areaCodeLand').val(), keys, function(areaCodeLand) {
													 $('#areaCodeLand').val(areaCodeLand);
													 $.jCryption.encrypt($('#phNumberLand').val(), keys, function(phNumberLand) {
														 $('#phNumberLand').val(phNumberLand);
														 $.jCryption.encrypt($('#areaCodeFax').val(), keys, function(areaCodeFax) {
															 $('#areaCodeFax').val(areaCodeFax);
															 
															 $.jCryption.encrypt($('#phNumberFax').val(), keys, function(phNumberFax) {
																 $('#phNumberFax').val(phNumberFax);
																 
																			 $.jCryption.encrypt($('#encautosettle').val(), keys, function(autosettle) {
																				 $('#encautosettle').val(autosettle);
																				 
																				 $.jCryption.encrypt($('#MerchantE').val(), keys, function(MerchantE) {
																					 $('#MerchantE').val(MerchantE);
																					 
																					 $.jCryption.encrypt($('#customersE').val(), keys, function(customersE) {
																						 $('#customersE').val(customersE);
																						 
																						 $.jCryption.encrypt($('#MerchantS').val(), keys, function(MerchantS) {
																							 $('#MerchantS').val(MerchantS);
																							 
																							 $.jCryption.encrypt($('#customersS').val(), keys, function(customersS) {
																								 $('#customersS').val(customersS);
																								 
																								 $.jCryption.encrypt($('#integrationType').val(), keys, function(integrationType) {
																									 $('#encintegrationType').val(integrationType);
																									 
																									 $.jCryption.encrypt($('#isreturnrefundpolicyonsite').val(), keys, function(isreturnrefundpolicyonsite) {
																										 $('#encisreturnrefundpolicyonsite').val(isreturnrefundpolicyonsite);
																										 
																										 $.jCryption.encrypt($('#returnrefundpolicylink').val(), keys, function(returnrefundpolicylink) {
																											 $('#returnrefundpolicylink').removeAttr('disabled').val(returnrefundpolicylink);
																											 
																											 $.jCryption.encrypt($('#classification').val(), keys, function(classification) {
																												 $('#encclassification').val(classification);
																												 
																												 $.jCryption.encrypt($('#checkSumDtl').val(), keys, function(checkSumDtl) {
																													 $('#enccheckSumdtl').val(checkSumDtl);
																											
																													 $.jCryption.encrypt($('#flag').val(), keys, function(flag) {
																														 $('#flag').val(flag);
																														 
																														 $.jCryption.encrypt($('#isCheckSumApplicable').val(), keys, function(isCheckSumApplicable) {
																															 $('#isCheckSumApplicable').val(isCheckSumApplicable);
																														 
																														 
																														 $.jCryption.encrypt($('#offlineflag').val(), keys, function(offlineflag) {
																															 $('#offlineflag').val(offlineflag);
																														 
																															 $.jCryption.encrypt($('#userLogin').val(), keys, function(userLogin) {
																																 $('#userLogin').val(userLogin);
																																 
																														 
																														 $.jCryption.encrypt($('#isRefundSettle').val(), keys, function(isRefundSettle) {
																															 $('#encisRefundSettle').val(isRefundSettle);
																															 
																															 $.jCryption.encrypt($('#attemptsallowed').val(), keys, function(attemptsallowed) {
																																 $('#encattemptsallowed').val(attemptsallowed);
																																 
																																 $.jCryption.encrypt($('input[name=timeallowed]:checked').val(), keys, function(timeallowed) {
																																	 $('input[name=timeallowed]:checked').val(timeallowed);
																																	 $.jCryption.encrypt(($('#timeminute').val()==null)?"":$('#timeminute').val(), keys, function(timeminute) {
																																		 $('#enctimeminute').val(timeminute);
																																		 
																																		 $.jCryption.encrypt($('#moduleName').val(), keys, function(moduleName) {
																																			 $('#encmoduleName').val(moduleName);
																																			 
																																				 $.jCryption.encrypt($('input[name=noofattempts]:checked').val(), keys, function(noofattempts) {
																																					 $('input[name=noofattempts]:checked').val(noofattempts);
																																					 
																																					 $.jCryption.encrypt($('#gstnNumber').val(), keys, function(gstnNumber) {
																																						 $('#gstnNumber').val(gstnNumber);
																																						 
																																						 $.jCryption.encrypt($('#merchantID').val(), keys, function(merchantID) {
																																							 $('#merchantID').val(merchantID);
																																							 
																																							 $.jCryption.encrypt($('#businessName').val(), keys, function(businessName) {
																																								 $('#encbusinessName').val(businessName);
																																								 
																																								 $.jCryption.encrypt($('input[name=pushresponseauth]:checked').val(), keys, function(pushresponseauth) {
																																									 $('input[name=pushresponseauth]:checked').val(pushresponseauth);
																																									 
																																									 $.jCryption.encrypt($('#pushresponseUsername').val(), keys, function(pushresponseUsername) {
																																										 $('#pushresponseUsername').val(pushresponseUsername);
																																										 
																																										 $.jCryption.encrypt($('#pushresponsePassword').val(), keys, function(pushresponsePassword) {
																																											 $('#pushresponsePassword').val(pushresponsePassword);
																																											 
																																											 $.jCryption.encrypt($('#pushresponseRepassword').val(), keys, function(pushresponseRepassword) {
																																												 $('#pushresponseRepassword').val(pushresponseRepassword);
																																												 
																																												 $.jCryption.encrypt($('#aggregatorName').val(), keys, function(aggregatorName) {
																																													 $('#aggregatorName').val(aggregatorName);
																																													 
																																													 $.jCryption.encrypt($('#encmerchantName').val(), keys, function(merchantName) {
																																														 $('#encmerchantName').val(merchantName);
																																														 $.jCryption.encrypt($('#mutaccount').val(), keys, function(mutaccount) {
																																															 $('#mutaccount').val(mutaccount);
																																															 
																																															 $.jCryption.encrypt($('#operatingMode').val(), keys, function(operatingMode) {
																																																 $('#operatingMode').val(operatingMode);
																																																 $.jCryption.encrypt($('#countryCode').val(), keys, function(countryCode) {
																																																	 $('#countryCode').val(countryCode);
																																																	 $.jCryption.encrypt($('#currencyCode').val(), keys, function(currencyCode) {
																																																		 $('#currencyCode').val(currencyCode);
																																																		 
																																																		 $.jCryption.encrypt($('#statusActiveInactive').val(), keys, function(statusActiveInactive) {
																																																			 $('#encstatusActiveInactive').val(statusActiveInactive);
																																																			 
																																																			 $.jCryption.encrypt($('#brandName').val(), keys, function(brandName) {
																																																				 $('#encbrandName').val(brandName);
																																																				 
																																																				 $.jCryption.encrypt($('#businessAddress').val(), keys, function(businessAddress) {
																																																					 $('#encbusinessAddress').val(businessAddress);
																																																					 
																																																					 $.jCryption.encrypt($('#businessCategory').val(), keys, function(businessCategory) {
																																																						 $('#encbusinessCategory').val(businessCategory);
																																																					 
																																																					 $.jCryption.encrypt($('#filingstatus').val(), keys, function(filingstatus) {
																																																						 $('#encfilingstatus').val(filingstatus);
																																																						 
																																																						 $.jCryption.encrypt($('#validFrom').val(), keys, function(validFrom) {
																																																							 $('#encvalidfrom').val(validFrom);
																																																							 
																																																							 $.jCryption.encrypt($('#validTo').val(), keys, function(validTo) {
																																																								 $('#encvalidto').val(validTo);
																																																								 
																																																								 $.jCryption.encrypt($('#settlementmode').val(), keys, function(settlementmode) {
																																																									 $('#encsettlementmode').val(settlementmode);
																																																									 
																																																									 $.jCryption.encrypt($('#stateName').val(), keys, function(stateName) {
																																																										 $('#encStatName').val(stateName);
																																																										 
																																																										 $.jCryption.encrypt($('#cityName').val(), keys, function(cityName) {
																																																											 $('#encCityName').val(cityName);
																																																											 
																																																											 $.jCryption.encrypt($('#pinCode').val(), keys, function(pinCode) {
																																																												 $('#pinCodeVal').val(pinCode); 
																																																											$.jCryption.encrypt($('#websiteTechnology').val(), keys, function(websiteTechnology) { //Added by nikhil
																																																												$('#encWebsiteTechnology').val(websiteTechnology); //Added by nikhil
																																																												 $.jCryption.encrypt($('#technologyVersion').val(), keys, function(technologyVersion) {
																																																													 $('#encTechnologyVersion').val(technologyVersion);
																																																								 
																																																			 document.formModifyDetails.submit();
																																																		    document.formModifyDetails.Modify.disabled = true;
																																																												 });
																																																										 });//Added by nikhil
																																																											 });
																																																										 });
																																																						});
																																																					});
																																																				});
																																																			  });
																																																			});
																																																		});
																																																	});
																																																 });
																																															});
																																														});
																																											 });
																																										 });
																																									 });
																																								 });
																																							 });
																																						 });
																																					});
																																				 });
																																			 });
																																		 });
																																	 });
																																 });
																															 });
																														 });
																													 });
																												 });
																											 });
																										 });
																									 });
																													 });				 
																								   });				 
																													 
																								 });
																							 });
																						 });
																					 });
																				 });
																			 });
																		 });
																	 });
																 });
															 });
														 });
													 });
												 });
											 });
										 });
									 });
								 });
							 });
						 });
					 });
		    	});
		    	});
			});
		    	
		    } else {
		    	$(location).attr('href',window.location.href+ "?PA1=" +  $('#PA1').val());
		    }
		
		}
		}

function isUrlValid(url) {
       //return /^(https:\/\/){1}([a-zA-Z0-9]+.)?((?!www.)[a-zA-Z][.-]{0,1}[a-zA-Z0-9]+)+.(aero|AERO|com|org|net|mil|edu|in|COM|ORG|NET|MIL|EDU|IN|co|CO|ac|AC|BIZ|biz|travel|TRAVEL|info|INFO|sbi|SBI|online|ONLINE|tv)[.]{0,1}$/i.test(url);
       return /^https:\/\/([\w\d\-]+\.)+\w{2,}(\/.+)?$/i.test(url);
}

function getKeys() {
	var a =  "/secure/EncryptionServlet1?generateKeypair=true";
	$.jCryption.getKeys(a, function(b) {
		keys = b
	})
}

jQuery(function(){
	   $('#validFrom').val($.datepicker.formatDate('dd-mm-yy')); 
	jQuery('#validFrom').datepicker({
			          changeMonth: true,
			          changeYear: true,
			          numberOfMonths: 1,
			          yearRange: '1900:2050',
			          dateFormat: 'dd-mm-yy',
			          style: 'margin-top:126px',
			          beforeShow: function(input, inst) {
			 		     
			 		    jQuery( this ).datepicker('option','maxDate', '0');
			 		    } 
			 		 });
	$('#validTo').val($.datepicker.formatDate('dd-mm-yy')); 
	jQuery('#validTo').datepicker({
			          changeMonth: true,
			          changeYear: true,
			          dateFormat: 'dd-mm-yy',
			 		 });
			 });



/*$(document).ready(function() 
{
	$("#stateName").change(function(){
		
		var filed = $("#stateName").val();
		alert("state"+filed);
		jQuery.ajax({
			type : "POST",
			dataType : 'xml',
			url : "aggMIFDropDown1.jsp?stateId="+filed,
			success : function(xml) 
			{
			
			var formOptions = "";
			$(xml).find("stateName").each(function(){
				$(this).find("option").each(function()
			        	{
				        		formOptions=formOptions+'<option value="'+$(this).attr("value")+'">'+$(this).text()+'</option>';
			        	});
			         	});
	    
	    	   $('#cityName').html(formOptions);
		
			},
			error: function(ts) {
				alert(ts.responseText) }
		});

	});

	/////////////////CODE FOR PIN////////////////////////
	$("#cityName").change(function(){
		var filed=document.getElementById("cityName").value;
		alert(filed);
		$.ajax({
			type : "POST",
			dataType : 'xml',
			url : "aggMERDropDown1.jsp?cityId="+filed,
			success : function(xml) 
			{ 
			var formLabel = "";
			$(xml).find("cityName").each(function(){
				$(this).find("label").each(function()
			        	{
					formLabel=$(this).text();
			        	});
			         	});	  alert(formLabel);  
	    	   
			   $('#pinCode').html(formLabel);
			   formLabel=$.trim(formLabel);
			   $('#pinCodeVal').val(formLabel);
			   if($.trim($("#pinCodeVal").val())!="")
					$("[for='pinCodeVal']").hide();
			}
		});
	});
});*/


$(document).ready(function() 
		{
	$('input#validFrom').val($('input#encvalidfrom1').val());
	$('input#validTo').val($('input#encvalidto1').val());
		});
