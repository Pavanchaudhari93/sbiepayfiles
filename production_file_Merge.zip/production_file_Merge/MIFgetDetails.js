
var isValidBranchAPI=true;
$(document).ready(function(){
	
	
	$("#isreturnrefundpolicyonsite").change(function()
	{
		if($.trim($("#isreturnrefundpolicyonsite").val())=="Y")
		{
			$("#returnrefundpolicylink").prop("disabled",false);
			$("#returnrefundpolicylink").rules("add", "required");
			
		}
		else
		{
			$("#returnrefundpolicylink").prop("disabled",true);
			$("#returnrefundpolicylink").rules("remove", "required");
		}
	});
	
	
	$('#checkEmailAvailable').click(function(){  
		
        if($('#emailUserName').val().length ==0 || $('#emailDomain').val().length ==0)
     	   alert("Please enter the email Id");
        else
           check_availability();  
         
    });
$('#websiteTechnology').change(function(){

	if($('#websiteTechnology').val() == ""){
		document.getElementById("technologyError").innerHTML = "Please select web technology";  
		 return false;
	}
	else{
		document.getElementById("technologyError").innerHTML = "";  
		 return true;
	}

	});


$('#technologyVersion').change(function(){

	if($('#technologyVersion').val() == "Select"){
		document.getElementById("technologyVersionError").innerHTML = "Please select web technology version";  
		 return false;
	}
	else{
		document.getElementById("technologyVersionError").innerHTML = "";  
		 return true;
	}

	});

	$("#panNumber").keyup(function(){

	var panN = $('#panNumber').val().toUpperCase();
      $('#panNumber').val(panN);

	});

// added by nikhil 15 July 2024 end 
	
	$("#gstnNumber").keyup(function(){

	var gstn = $('#gstnNumber').val().toUpperCase();
      $('#gstnNumber').val(gstn);

	});
	
	
	$('#fromMIFgetDetails').validate({    	
		
		rules : 
		{				
			searchSel :  { required	 : true		}						
		},

		messages : 
		{
			searchSel :  { required  : "Please select 	"	 },
			mifid 	  :  { required  : "MIF Id Required"	 },
			startDate :  { required  : "From date required"	 },
			endDate   :  { required  : "To date required" 	 }

		},
		errorElement: "div"

			}); 
	
	
$('#formMIF').validate({    	
		
		rules : 
		{				
			kycDate : "required",
		    /*emailFirst :{email : true},*/
		    emailLast:{email : "required"},  
		    emailDomain : {email1 : "required"},
		    merchantlogourl: { required:true ,complete_url: true},
		    merchantmobilepagelogourl: { complete_url: true},
		   	validfrom: "required",
		   	validto: "required",
		   	addRadio: "required",
		   	subRadio: "required",
		   	//merchantbelongsto:{check_item_dropdown : true},   					//added by Tushar Suryawanshi on 25-04-2022
		   	isreturnrefundpolicyonsite: "required",
		   	integrationType :  { check_item_dropdown : true },
		   	integrationModel :  { check_item_dropdown : true },
		   	classification :  { check_item_dropdown : true },
		   //moduleName :  { required : true, check_item_dropdown : true },
		   	settlementWindow  : { check_item_dropdown : true },
		   	settlementFee : { check_item_dropdown : true },
	        operatingMode : {check_item_dropdown: true },
	        countryCode : {check_item_dropdown: true },
	        currencyCode : {check_item_dropdown: true },
	        accessMediumCode:{check_item_dropdown: true },
	        serverurl:{check_url:true},
	        //webServicePostingURL:{required:true,webservice_url: true},
	        pushresponseUsername:{required:true,check_pushresponsefield:true},
	        pushresponsePassword:{required:true,passwordValidation:true},
	        pushresponseRepassword:{required:true, check_matchingpwd:true},
	        premiumPricing :  { check_item_dropdown : true },//Shashank Naik NTRP Accredited Bank Wise Pricing
	        gstnNumber :{ gstnCheck :true }, 
	        gstnNumber :{ gstnCheck :"Invalid GSTIN" },
		//added by Rohini for circle name and rm name validation on 09/06/2022
		//	circleName:{check_item_dropdown : true},  
			rmName:{check_item_dropdown : true}, 
		    branchCode:{required : true},
			chargebacks:{required : true},   //Added by pooja for chargeback
			panNumber:{panCheck : "Please Enter Valid PAN Number",
				maxlength : 10}, 
		},

		messages : 
		{
			kycDate 			: {required : "KYC Date required" },
		    merchantlogourl		: {required : "Merchant Logo URL required" },
		   validfrom			: {required : "Valid From Date required" },
		   validto				: {required : "Valid To Date required" },
		   addRadio				: {required : "required" },
		   subRadio				: {required : "required" },
		   //merchantbelongsto    : {check_item_dropdown:"Merchant Belongs To Required"},					//added by Tushar Suryawanshi on 25-04-2022
		   isreturnrefundpolicyonsite:  {required : "required" },
		   integrationType  	: { check_item_dropdown : "Integration Type required" },
		   integrationModel  	: { check_item_dropdown : "required" },
		   classification 		: { check_item_dropdown : "Classification required" },
		   //moduleName 			: { required : "Module Name required" ,check_item_dropdown : "Module Name required" },
		   settlementWindow 	: { check_item_dropdown : "Settlement Window required" },
		   settlementFee 		: { check_item_dropdown : "Settlement Fee required" },
		   operatingMode 		: { check_item_dropdown : "Operating Mode required" },
		   countryCode 			: { check_item_dropdown : "Country Code required" },
		   currencyCode 		: { check_item_dropdown : "Currency Code required" },
		   accessMediumCode		: {	check_item_dropdown	: "Access Medium required"},
		   returnrefundpolicylink:{required : "Refund Window required" },
		   //webServicePostingURL:{required : "Web Service Posting URL required" },
		   pushresponseUsername:{required:"Enter Push Response Username"},//Saneel
		   pushresponsePassword:{required:"Enter Push Response Password"},//Saneel
		   pushresponseRepassword:{required:"Enter Matching Password"},//Saneel
		   premiumPricing 		: { check_item_dropdown : "Premium Pricing required" },//Shashank Naik NTRP Accredited Bank Wise Pricing
		   gstnNumber :{ gstnCheck :"Invalid GSTIN" },
		   //added by Rohini for circle name and RM name validation on 09/06/2022
		   // circleName    : {check_item_dropdown:"Circle Name Required"},	
			rmName    : {check_item_dropdown:"RM Name Required"},	

			branchCode:{required : "Branch Code Required"},
            chargebacks:{required : "Chargeback IsApplicable Required"},   //Added by pooja for chargeback     
			panNumber:{panCheck : "Please Enter Valid PAN Number",
						maxlength : "PAN Number should be 10 Digit"			
									},
		   
		},
		errorElement: "div",
		
		groups: 
		{
			//emailgroup:	"emailFirst emailLast ",
			  emailFirst:  "emailFirst",
			//	emailgroup1 : "emailUserName emailDomain"
			  emailUserName:  "emailUserName"
		},
		 errorPlacement: function(error, element) {
	           
	        	if ( element.attr("name") == "emailFirst" || element.attr("name") == "emailLast")
	            error.insertAfter("#emailLast");
	            else
	            error.insertAfter(element); 
	
	           
        	if ( element.attr("name") == "emailUserName" || element.attr("name") == "emailDomain")
            error.insertAfter("#emailDomain");
            else
            error.insertAfter(element); 
        	if ( element.attr("name") == "gstnNumber")
	            error.insertAfter("#gstnNumber");
	            else
	            error.insertAfter(element); 
	 }
			}); 
	


$("#emailLast").blur(function(){
	$("#emailFirst").blur();
	});

$("#gstnNumber").blur(function(){
	$("#gstnNumber").blur();
	});

$("#emailDomain").blur(function(){
	$("#emailUserName").blur();
	});

	$.validator.addMethod("panCheck", function(value, element) 
		{								
	 return this.optional(element) || /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/i.test(value);  
 		}, "PAN Number Required");
$.validator.addMethod("gstnCheck", function(value, element) 
		{								
	 return this.optional(element) || /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/i.test(value);  
 		}, "Invalid GSTIN"); 

$.validator.addMethod("check_item_dropdown", function(value, element) {
	return this.optional(element)|| $.trim(value) != "";
}, "required");
$.validator.addMethod("check_pushresponsefield", function(value, element) {
	return this.optional(element)|| $.trim(value) != "" ;		
}, "required");


$.validator.addMethod("check_matchingpwd", function(value, element) {
	var newPassword=$('#pushresponsePassword').val();
	var pushresponseRepassword=$('#pushresponseRepassword').val();
	if(newPassword!=pushresponseRepassword){
		return false;
	}else{
		return true;
	}
	
	
	
},"Enter Matching Password");

$.validator.addMethod("passwordValidation", function(value, element) {
	var newPassword=$('#pushresponsePassword').val();

	var specialChars=/[\x20|\x5F|\x2D|\x40|\x2F|\x3A|\x2C]+/g;

	if((newPassword.length>0 && newPassword.length<8) || specialChars.test(newPassword)){
		return false;
	}else{
		return true;
	}
	
	
	
},"Must contain alphanumeric minimum 8 length character");
if($('#websiteTechnology').val() == "Select"){
		document.getElementById("technologyError").innerHTML = "Please select web technology";  
		 return false;
	}
	
	
if($('#technologyVersion').val() == "Select"){
		document.getElementById("technologyVersionError").innerHTML = "Please select web technology version";  
		 return false;
	}
	
	
$.validator.addMethod("email", function(value, element)
		{ 
	    var emailId=$('#emailFirst').val()+"@"+$('#emailLast').val();
	    if(emailId!=""+"@"+""){
	    return /^[a-zA-Z0-9._-]+@[A-Za-z0-9-]+(.[A-Za-z0-9]+)*(.[A-Za-z]{2,5})$/i.test(emailId);}
	    else{
	    	return true;
	    }
		}, "Please enter a valid email address");



$.validator.addMethod("email1", function(value, element)
		{ 
	    var emailId=$('#emailUserName').val()+"@"+$('#emailDomain').val();
	    return /^[a-zA-Z0-9._-]+@[A-Za-z0-9-]+(.[A-Za-z0-9]+)*(.[A-Za-z]{2,5})$/i.test(emailId);
		}, "Please enter a valid email address");


/*$.validator.addMethod("complete_url", function(val, elem) {
    if (val.length == 0) { return true; }
 
  ///return /^(http[s]?:\/\/){0,1}(www\.){0,1}[a-zA-Z0-9\.\-]+\.(com|org|net|mil|edu|COM|ORG|NET|MIL|EDU|IN)[\.]{0,1}/i.test(val);
 
return /^(https?|ftp):\/\/+(www\.)[A-Za-z0-9_-]+\.+[A-Za-z0-9.\/%&=\?_:;-]+$/i.test(val);
  
},"Please enter valid address.");*/

$.validator.addMethod("check_url", function(value, element)
		{ 
			var url=$('#serverurl').val();
			if(document.getElementById("flag").checked == true)
			{
				if($('#serverurl').val()==null || $('#serverurl').val()=="" )
				{
					return false;
				}
				else {
				/*	var formLabel = "";
			    	var regexURL ="";
			    	var isSuccess = false;

			    	$.ajax({
			    	      type: "POST",
			    	       url: "aggDomainValidation.jsp",
			    	      data: "parameter="+url,
			    	      async: false, 
			    	      dataType:'xml',
			    	   success: function(xml)
			    	   {
			    		   $(xml).find("aggID").each(function(){
			    		   	$(this).find("label").each(function(){
			    		   		formLabel=$.trim($(this).text());
			    		   		 regexURL =  "^(https:\/\/){1}(www\\.)?((?!www\\.)[a-zA-Z0-9]*[\\.\\-]{0,1}[a-zA-Z0-9]+)+\\.("+formLabel+")\\b([-a-zA-Z0-9@:%_\\+.~#?&]*)";
			    		           	});
			    		            	});	
					    		   if(new RegExp(regexURL).test(url)){
					    			   isSuccess = true;
					    		   }
			    		 }
			    	});*/
			        if (url.length == 0) { 
			        	return true; 
			        	}
			        //return isSuccess;
				//return /^(https:\/\/){1}(www\.)?((?!www\.)[a-zA-Z0-9]*[\.\-]{0,1}[a-zA-Z0-9]+)+\.(com|org|net|mil|edu|in|COM|ORG|NET|MIL|EDU|IN|ac|AC|info|INFO|co|CO|sbi|SBI])\b([-a-zA-Z0-9@:%_\+.~#?&]*)/i.test(url);
				 return /^https:\/\/([\w\d\-]+\.)+\w{2,}(\/.+)?$/i.test(val);
				}
			}
		},"Please enter valid Push Response URL. https:// is mandatory.");



$.validator.addMethod("complete_url", function(val, elem) {

	/*var formLabel = "";
	var regexURL ="";
	var isSuccess = false;

	$.ajax({
	      type: "POST",
	       url: "aggDomainValidation.jsp",
	      data: "parameter="+val,
	      async: false, 
	      dataType:'xml',
	   success: function(xml)
	   {
		   $(xml).find("aggID").each(function(){
		   	$(this).find("label").each(function(){
		   		formLabel=$.trim($(this).text());
		   		
		   		 regexURL =  "^(https:\/\/){1}(www\\.)?((?!www\\.)[a-zA-Z0-9]*[\\.\\-]{0,1}[a-zA-Z0-9]+)+\\.("+formLabel+")[\\.]{0,1}(\/[a-zA-Z0-9_]*[\\.\\-]{0,1}[a-zA-Z0-9_]+)+\\.(JPG|jpg|TIFF|tiff|GIF|gif|BMP|bmp|PNG|png|JPEG|jpeg|JFIF|jfif|IMG|img){1}$";
		           	});
		            	});	
	    		   if(new RegExp(regexURL).test(val)){
	    			   isSuccess = true;
	    		   }
		 }
	});*/
    if (val.length == 0) { 
    	return true; 
    	}
   /* return isSuccess;*/
  //return /^(https:\/\/){1}(www\.)?((?!www\.)[a-zA-Z0-9]*[\.\-]{0,1}[a-zA-Z0-9]+)+\.(com|org|net|mil|edu|in|COM|ORG|NET|MIL|EDU|IN|sbi|SBI)[\.]{0,1}(\/[a-zA-Z0-9_]*[\.\-]{0,1}[a-zA-Z0-9_]+)+\.(JPG|jpg|TIFF|tiff|GIF|gif|BMP|bmp|PNG|png|JPEG|jpeg|JFIF|jfif|IMG|img){1}$/i.test(val);
  	 return /^https:\/\/([\w\d\-]+\.)+\w{2,}(\/.+)?$/i.test(val);//added by mala
},"Please enter valid Logo URL. https:// is mandatory.");

$.validator.addMethod("webservice_url", function(val, elem) {
	/*var formLabel = "";
	var regexURL ="";
	var isSuccess = false;

	$.ajax({
	      type: "POST",
	       url: "aggDomainValidation.jsp",
	      data: "parameter="+val,
	      async: false, 
	      dataType:'xml',
	   success: function(xml)
	   {
		   $(xml).find("aggID").each(function(){
		   	$(this).find("label").each(function(){
		   		formLabel=$.trim($(this).text());
		   		 regexURL =  "^(https:\/\/.)?(www\\.)?[-a-zA-Z0-9._\\@+]{2,256}\\.("+formLabel+")\\b([-a-zA-Z0-9@:%_\\+.~#?&]*)";
		           	});
		            	});	
	    		   if(new RegExp(regexURL).test(val)){
	    			   isSuccess = true;
	    		   }
		 }
	});*/
    if (val.length == 0) { 
    	return true; 
    	}
   // return isSuccess;
   //return/^(https:\/\/.)?(www\.)?[-a-zA-Z0-9._\@+]{2,256}\.(com|org|net|mil|edu|in|COM|ORG|NET|MIL|EDU|IN|ac|AC|sbi|SBI])\b([-a-zA-Z0-9@:%_\+.~#?&]*)/i.test(val);
    return /^https:\/\/([\w\d\-]+\.)+\w{2,}(\/.+)?$/i.test(val);
},"Please enter valid Web Service Posting URL. https:// is mandatory.");


/**********************************function for date***********************************************/	
	
jQuery(function(){
	$('#kycDate').val($.datepicker.formatDate('dd-mm-yy', new Date()));

	  jQuery('#kycDate').datepicker({ 
      showOn: "button",
		buttonImage: "../images/calendar.gif",
		buttonImageOnly: true,
	    changeMonth: true,
	    changeYear: true,
	    numberOfMonths: 1,
	    dateFormat: 'dd-mm-yy',
	    style: 'margin-top:126px',
	                      
	    beforeShow: function(input, inst) 
	    {
	    	
	   	    		jQuery( this ).datepicker('option','maxDate', '0');
	    	
	    }
	});

 

  });



$("#mifid").change(function() 
		{

			var field =$('select[name="mifid"]').val();
			
			jQuery.ajax(
			{
				type : "POST",
				dataType : 'xml',
				url : "aggCheckMIFEmailId.jsp",
				data:{PA11:field},
				success : function(xml) 
				{
					var redirectURL="";
					$(xml).find("XSSERROR").each(function()
					{
						$(xml).find("REDIRECT").each(function()
						{
							redirectURL=$(this).text();
						});
						$(xml).find("URL").each(function()
						{
							redirectURL=redirectURL+"?"+$(this).text();
						});
						$(xml).find("QSTRING").each(function()
						{
							redirectURL=redirectURL+"&"+$(this).text();
						});
						
						$(xml).find("PARAMNAME").each(function()
						{
							if($.trim($(this).text())!="")
								redirectURL=redirectURL+"&"+$(this).text();
						});
						$(xml).find("PARAMVAL").each(function()
						{
							if($.trim($(this).text())!="")
								redirectURL=redirectURL+"&"+$(this).text();
						});
									
						document.location.href=redirectURL;
					});
					
				}/*,
				error:function()
		     	{
		     		alert("An error occured. Please Try again.");
		     	}*/
			});
		});


if($('#noofattemptsyes').is(":checked"))
{
  	var Options = {"1": "1",
    			  "2": "2",
    			  "3": "3"
    			};
    	
    	for(var k=1;k<=99;k++){
    		Options[k]=k;
    	}

    			var $attempts = $("#attemptsallowed");
    			$attempts.empty(); // remove old options
    			$.each(Options, function(value,key) {
    			  $attempts.append($("<option></option>")
    			     .attr("value", value).text(key));
    			});
    	
    	
    

}
$('#noofattemptsyes').on("click",function(){
var newOptions = {"1": "1",
		  "2": "2",
		  "3": "3"
		};

for(var i=1;i<=99;i++){
	newOptions[i]=i;
}

		var $el = $("#attemptsallowed");
		$el.empty(); // remove old options
		$.each(newOptions, function(value,key) {
		  $el.append($("<option></option>")
		     .attr("value", value).text(key));
		});


});



$('#noofattemptsone').on("click",function(){
var oneSucesss = {"INFINITE": "INFINITE"};

 	var $el = $("#attemptsallowed");
		$el.empty(); // remove old options
		$.each(oneSucesss, function(value,key) {
		  $el.append($("<option></option>")
		     .attr("value", value).text(key));
		});
	
	});

$('#timeallowedyes').on("click",function(){
var timedisp = {};

for(var j=5;j<=120;j++){
	timedisp[j]=j;
}

		var $time = $("#timeminute");
		$time.empty(); // remove old options
		$.each(timedisp, function(value,key) {
		  $time.append($("<option></option>")
		     .attr("value", value).text(key));
		});


});


setPushResponse=function (pushResponse)
{
	
	if(pushResponse == "Y")
	{
		
		$('#pushresponseUsername').val("");
		 $("#pushresponsePassword").val("");
		 $("#pushresponseRepassword").val("");
		$("#pushresponseauthForm").slideDown();	
		
	}
	
	if(pushResponse == "N")
	{
		 $('#pushresponseUsername').val("");
		 $("#pushresponsePassword").val("");
		 $("#pushresponseRepassword").val("");
		$("#pushresponseauthForm").slideUp();
		
	}
	
	
}

/*********************************end of function**************************************/	

 $('#branchCode').on('keyup',function(){
		 


                var branchCode=$(this).val();

				  if(branchCode==""){
                  			document.getElementById("branchCodeError2").style.display = "none";
							$("branchCodeError2").text("");	
							$('#branchName').val("");
							$('#circleCode').val("");
							$('#circleName').val("");

					return;
				}

				 if (branchCode != "" && branchCode=='00000') {
						   document.getElementById( 'branchCodeError2' ).style.display = 'none';
			 document.getElementById('branchCodeError2').style.display = 'block';
			 document.getElementById("branchCodeError2").innerHTML = "Requested Branch Code Does Not Exist";
			  $("[for=branchCode]").css("display", "none");
			
			
		    return false;
		  }

		   //special char validation -23jan2024
				var numberRegex = /^\d+$/;
				if (branchCode != "" && !numberRegex.test(branchCode)) {
			 document.getElementById( 'branchCodeError2' ).style.display = 'none';
			 document.getElementById('branchCodeError2').style.display = 'block';
			 document.getElementById("branchCodeError2").innerHTML = "Enter Only Digits";
			 $("[for=branchCode]").css("display", "none");
			
		    return false;
		  }

				var branchCodeLength = $("#branchCode").val().length;
                

                $('#branchCode').prop("readonly",false);
                $('select[name="branchCode"]').empty();
				var loginId = $('#userId').val();
				var title = $('#title').val();
                if(branchCode != null ) {
	                 $.ajax({
	                  url: "aggMIFRegisterActionAjax.jsp",
	                  type: "GET",
	                  dataType: "json",
	                  data : {branchCode : branchCode,
							  loginId : loginId,
							  title : title
					},
	                  success: function(data){
	                  if(data != null){
						   if(data[1]=="Eis application in active")
						  {
                             isValidBranchAPI=false;


                               document.getElementById("branchCodeError2").innerHTML ="EIS Application Is InActive";
							   document.getElementById("branchCodeError2").style.display ="block";
							   $("[for=branchCode]").css("display", "none");
                                $('#branchName').val("");
	  							$('#circleCode').val("");
	  							$('#circleName').val("");					  
								return false;

						  }
	                	   
						  
	                	  if(data[1] != 'REQUESTED PARAMETER RECORD DOESN T EXIST'){
	    	                
	  	                    $('#browsers').empty();

	  						if(branchCodeLength != 5){
	  							document.getElementById("branchCodeError2").style.display = "none";
								$("branchCodeError2").text("");	
	  							$('#branchName').val("");
	  							$('#circleCode').val("");
	  							$('#circleName').val("");

	  							$.each(data,function(index,val){
	  	                   
	  	                    	$('#browsers').append('<option value="'+data[index]+'"> </option>');	
	  	                       
	  							});
	  							
	  						}else{
									/*var branchNames=data[0].replaceAll("[^a-zA-Z0-9]", " ");
								   var circleNames=data[7].replaceAll("[^a-zA-Z0-9]", " ");
	  								$('#branchName').val(branchNames);
	  					 			$('#circleCode').val(data[1].substring(1));
	  								$('#circleName').val(circleNames);*/

	  								$('#branchName').val(data[0].replaceAll(/[^a-zA-Z0-9 ]/g," "));
	  					 			$('#circleCode').val(data[1].replaceAll(/[^a-zA-Z0-9 ]/g," "));
	  								$('#circleName').val(data[7].replaceAll(/[^a-zA-Z0-9 ]/g," "));
	  												}
	                		  
	                	  }
	                	  else
	                		  {
	                		
			            	//var msg = 'Enter Valid Branch Code';
			          document.getElementById("branchCodeError2").innerHTML = "Requested Branch Code Does Not Exist";
					  document.getElementById("branchCodeError2").style.display = "block";
	                		 
	                		  }

					  }
	
	                  },
	                  
			            error: function (jqXHR, exception) {
			            	var msg = 'Error While Serving Request';
			          
			            },
	         
	                 });
                }
           });
	
	
});

function enableText(checkBool, textID)
{
  textFldObj = document.getElementById(textID);
  //Disable the text field
  textFldObj.disabled = checkBool;
  //Clear value in the text field
  if (!checkBool) { textFldObj.value = ''; }
}

function serverCom()
{
	
	if($('#flag').is(":checked"))
	{
		
	    $('#serverurl').val('');
	    $("#urlserver").css("display","table-row");
	    $("#servereurl").css("display","none");
	    $("#pushresponseauthID").css("display","table-row");
	    $("#pushresponseauthN").attr('checked','checked');
	}
	else
	{
		$('#serverurl').val('');
		$("#urlserver").css("display","none");
		 $("#servereurl").css("display","none");
		 $("#pushresponseauthID").css("display","none");
		 $("#pushresponseauthForm").slideUp();
		 $('#pushresponseUsername').val("");
		 $("#pushresponsePassword").val("");
		 $("#pushresponseRepassword").val("");
	}

}
//Parag Davkhar added for checksum start
function checkSum()
{
	if($('#isCheckSumApplicable').is(":checked"))
	{
		
	  
	    $("#checkurl").css("display","table-row");
	 
	    
	}
	else
	{
		
		$("#checkurl").css("display","none");
		 
	}
}
function checkAutoRefund()
{
	if((document.getElementById("autoRefundDays").value=="")&&(eval("document.formMIF.autosettle.checked")==false))
		{
		alert("Please check the autosettlement or enter the days");
		return false;
		}
	else {
		
		return true;
		} 
	
	}


function emailAvailable()
{
	
	var emailId=$('#emailUserName').val()+"@"+$('#emailDomain').val();         
    $.post("aggCheckMIFEmailId.jsp", { emailId: emailId },   
 		 function(result1){
    	
    	if(result1 == 1){
    		
            alert(emailId + ' already exist');
            return false;
          }else{  
                return true;
              } 	
    });
}


function check_availability(){
	 
	var emailId=$('#emailUserName').val()+"@"+$('#emailDomain').val();         
      $.post("aggCheckMIFEmailId.jsp", { emailId: emailId },   
   		 function(result){               
    	  if(result == 1){      
           alert(emailId + ' is not Available');
         }else{  
               alert(emailId + ' is Available');
             }  
  });   

}

function RegId(j){
	document.getElementById("index").value=j;
	document.formMIFReg.submit();
}


function timeChecker()
{
	
	if($('#timeallowedyes').is(":checked"))
	{
		
	    $("#timedisp").css("display","table-row");
	    $("#timeminute").css("display","block");
	}
	else
	{
		$('#timeminute').empty();
		$("#timedisp").css("display","none");
		 $("#timeminute").css("display","none");
	}

}
function webServiceChecker()
{
	
	if($('#moduleName').val()=="MERCHANTBANKACCOUNT")
	{
		
	    $("#webServicePostingURLLabel").css("display","table-row");
	    $("#webServicePostingURL").css("display","block");
	}
	else
	{
		$('#webServicePostingURL').empty();
		$("#webServicePostingURLLabel").css("display","none");
		 $("#webServicePostingURL").css("display","none");
	}

}

function setNext(){
		 if(!isValidBranchAPI){
			  return false;
		  }
	  var pan = $('#panNumber').val();
	  var regex="[A-Z]{5}[0-9]{4}[A-Z]{1}"


	   if (pan.match(regex)) {
		    if(pan.length != 10){
			 document.getElementById("panNumberError").innerHTML = "PAN Number should be 10 Digit";
			 $("#panNumberError").css("display","block");
			 return false;
			
			}else{
			 document.getElementById("panNumberError").innerHTML = "";
			  $("#panNumberError").css("display","none");
			
		    }
	   }else{
		   if(pan == ""){
			   			  document.getElementById("panNumberError").innerHTML = "";
						  $("#panNumberError").css("display","none");
						  

	   }else{
			  document.getElementById("panNumberError").innerHTML = "Please Enter Valid PAN Number";
			   $("#panNumberError").css("display","block");
			  return false;
	   }
		  }
		
		// added By Nikhil
		if($('#websiteTechnology').val() == ""){
		document.getElementById("technologyError").innerHTML = "Please select web technology";  
		 return false;
	     }
	
		 // added By Nikhil
        if($('#technologyVersion').val() == "Select"){
		document.getElementById("technologyVersionError").innerHTML = "Please select web technology version";  
		 return false;
	     }
	  var remarks = document.getElementById("branchCode").value;
	  var remarks1 = document.getElementById("branchName").value;
	  document.getElementById('branchCodeError2').style.display = 'none';
	  document.getElementById("branchCodeError2").innerHTML = "";
	
		   if (remarks != "" && remarks1=="") {
			 document.getElementById('branchCodeError2').style.display = 'block';
			 document.getElementById("branchCodeError2").innerHTML = "Requested Branch Code Does Not Exist";
		
		    return false;
		  }

		   //special char validation -23jan2024
				var numberRegex = /^\d+$/;
				if (remarks != "" && !numberRegex.test(remarks)) {
			document.getElementById( 'branchCodeError2' ).style.display = 'none';
			 document.getElementById('branchCodeError2').style.display = 'block';
			 document.getElementById("branchCodeError2").innerHTML = "Enter Only Digit";
			 $("[for=branchCode]").css("display", "none");
			
		    return false;
		  }
	var flag=validateSubmitForm();
	if(flag==true){
	 var formValid= $("#formMIF").valid();
	 if(formValid==true)
		{
		document.formMIF.submit();
	    document.formMIF.GenerateMerchantID.disabled = true;
		}
		}
}






