const report = require("multiple-cucumber-html-reporter");
const dayjs = require("dayjs");
const fs = require("fs");

const data = fs.readFileSync("./cypress/support/executionTime.json", {
  encoding: "utf8",
  flag: "r",
});
const runInfos = JSON.parse(data);

report.generate({
  jsonDir: "./cypress/CucumberReports",
  reportPath: "cypress/CucumberReports/cucumber-htmlreport.html",
  metadata: {
    browser: {
      name: "chrome",
      version: "100",
    },
    device: "Local test machine",
    platform: {
      name: "Windows",
      version: "16.04",
    },
  },
  customData: {
    title: "Run Info",
    data: [
      { label: "Project", value: "SBIEPAY " },
      { label: "Release", value: "1.0.0" },
      {
        label: "Execution Start Time",
        value: dayjs(runInfos["startTime"]).format("YYYY-MM-DD HH:mm:ss"),
      },
      {
        label: "Execution End Time",
        value: dayjs(runInfos["endTime"]).format("YYYY-MM-DD HH:mm:ss"),
      },
      // {
      //   label: "Execution Duration",
      //   value: (runInfos["duration"]),
      // },
    ],
  },
});
