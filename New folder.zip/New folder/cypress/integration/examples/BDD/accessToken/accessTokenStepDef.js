import { When, Then } from "@badeball/cypress-cucumber-preprocessor";
import accessToken from "../../../../support/pageObjects/accessToken";

When(
  "user generate access token for mid {string} and secretkey is {string}",
  function (mid, key) {
    accessToken.getAccessToken(mid, key).as("response");
  }
);

Then("the response status code should be {int}", function (statusCode) {
  cy.get("@response").then((response) => {
    cy.log(response.body);
    cy.checkStatusCode(response, statusCode);
  });
});

Then("the response body verification", function () {
    cy.get("@response").then((response) => {
        cy.checkResponseBodyProperty(response.body, "data");
      });
});
