import {When, Then } from "@badeball/cypress-cucumber-preprocessor";
import transactionToken from "../../../../support/pageObjects/transactionToken"

When(
  "user send request for transation token generation with {string}, {string} and HASH value of orderID+MID {string}",
  function (mid, secretkey, hash) {
    transactionToken.getTransactionToken(mid, secretkey, hash).as("response")
  }
);

Then("the response status code should be {int}", function (statusCode) {
    cy.get("@response").then((response) => {
        cy.log(response.body)
        cy.checkStatusCode(response, statusCode);
    })
});

Then("the response body verification", function () {

});
