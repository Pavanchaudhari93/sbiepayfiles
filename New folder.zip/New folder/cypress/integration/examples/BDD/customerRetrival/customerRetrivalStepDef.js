import { Given, When, Then } from "@badeball/cypress-cucumber-preprocessor";
import customerRetrival from "../../../../support/pageObjects/customerRetrival";
import accessToken from "../../../../support/pageObjects/accessToken";

var token = "";

Given(
  "user generate access token for mid {string} and secretkey is {string}",
  function (mid, key) {
    accessToken.getAccessToken(mid, key).as("getToken");
    cy.get("@getToken").then((getAccessToken) => {
      token = getAccessToken.body.data;
    });
  }
);

When("user send a post request for expire generated token", function () {
  accessToken.toExpireToken(token).as("expiredTokenResponse");
});

Then(
  "verify expired token response body parameter status {int} and errorMessage {string}",
  function (status, errorMessage) {
    cy.get("@expiredTokenResponse").then((response) => {
      cy.checkStatusCode(response, 200);
      cy.checkResponseBodyNotEmpty(response);
      cy.checkResponseBodyProperty(response.body, "data");
      cy.checkResponseBodyPropertyValue(response.body, "status", status);
      expect(response.body)
        .to.have.property("data")
        .that.is.an("array")
        .and.includes(errorMessage);
    });
  }
);

When(
  "user send a GET request with customerID {string} and invalid {string}",
  function (customerID, invalidToken) {
    customerRetrival.getUserData(invalidToken, customerID).as("response");
  }
);

When(
  "user send a GET request with customerID {string} and generated token",
  function (customerID) {
    customerRetrival.getUserData(token, customerID).as("response");
  }
);

When(
  "user send a GET request with invalid Endpoint {string} and customerID {string} and generated token",
  function (endpoint, customerID) {
    customerRetrival
      .getUserDataForInvalidEndPoint(token, endpoint, customerID)
      .as("response");
  }
);

Then("the response status code should be {int}", function (statusCode) {
  cy.get("@response").then((response) => {
    cy.log(response.body);
    cy.checkStatusCode(response, statusCode);
  });
});

Then(
  "the response body parameter status verification {int}",
  function (status) {
    cy.get("@response").then((response) => {
      cy.log(response.body);
      cy.checkResponseBodyNotEmpty(response);
      cy.checkResponseBodyProperty(response.body, "data");
      cy.checkResponseBodyProperty(response.body.data[0], "customerId");
      cy.checkResponseBodyProperty(response.body.data[0], "customerResponse");
      cy.checkResponseBodyPropertyValue(response.body, "status", status);
    });
  }
);

Then("verify customerID in response {string}", function (custID) {
  cy.get("@response").then((response) => {
    cy.checkResponseBodyPropertyValue(
      response.body.data[0],
      "customerId",
      custID
    );
  });
});

Then(
  "verify the fail response body parameter status {int} error code {string} and errorMessage {string}",
  function (status, errCode, errorMessage) {
    cy.get("@response").then((response) => {
      cy.checkResponseBodyNotEmpty(response);
      cy.checkResponseBodyProperty(response.body, "errors");
      cy.checkResponseBodyPropertyValue(response.body, "status", status);
      cy.checkResponseBodyPropertyValue(
        response.body.errors[0],
        "errorCode",
        errCode
      );
      cy.checkResponseBodyPropertyValue(
        response.body.errors[0],
        "errorMessage",
        errorMessage
      );
    });
  }
);
