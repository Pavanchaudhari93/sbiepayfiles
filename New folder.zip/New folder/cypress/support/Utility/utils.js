// Wait for an Element to Be Visible : cy.waitForElementVisible('selector');
Cypress.Commands.add("waitForElementVisible", (selector, timeout = 10000) => {
  cy.get(selector, { timeout }).should("be.visible");
});

// Wait for an Element to Be Clickable : cy.waitForElementClickable('selector');
Cypress.Commands.add("waitForElementClickable", (selector, timeout = 10000) => {
  cy.get(selector, { timeout }).should("be.enabled").and("be.visible").click();
});

// Clear and Type into an Input Field : cy.clearAndType('selector', 'text');
Cypress.Commands.add("clearAndType", (selector, text) => {
  cy.get(selector).clear().type(text);
});

/* Utility method to type text into an element :   cy.typeIntoElement('selectot', 'text') | 
                                                   cy.typeIntoElement('selectot', 'text', { waitForElement: true }); |   
                                                   cy.typeIntoElement('selectot', 'text', { clearBeforeType: true });
                                                   */
Cypress.Commands.add("typeIntoElement", (selector, text, options = {}) => {
  const { clearBeforeType = true, delay = 0, waitForElement = false } = options;

  if (waitForElement) {
    cy.get(selector).should("be.visible"); // Wait until the element is visible before typing
  }

  cy.get(selector).then(($el) => {
    if (clearBeforeType) {
      $el.clear(); // Optionally clear the input field before typing
    }

    cy.wrap($el)
      .type(text, { delay }) // Type the text with an optional delay
      .should("have.value", text); // Verify the field contains the typed value
  });
});

// Verify Page Title : cy.verifyPageTitle('title');
Cypress.Commands.add("verifyPageTitle", (title) => {
  cy.title().should("include", title);
});

// Check if Element is Present : cy.checkElementPresent('selector');
Cypress.Commands.add("checkElementPresent", (selector) => {
  cy.get("body").then(($body) => {
    if ($body.find(selector).length > 0) {
      cy.get(selector).should("be.visible");
    } else {
      cy.log(`Element ${selector} not found`);
    }
  });
});

// Click : cy.click('selector');
Cypress.Commands.overwrite("click", (selector) => {
  cy.get(selector).click();
});

// Force Click / Clicking on a Disabled Element : cy.forceClick('selector');
Cypress.Commands.add("forceClick", (selector) => {
  cy.get(selector).click({ force: true });
});

// rightClick : cy.rightClick('selector');
Cypress.Commands.add("rightClick", (selector) => {
  cy.get(selector).rightclick();
});

// doubleClick : cy.doubleClick('selector');
Cypress.Commands.add("dblClick", (selector) => {
  cy.get(selector).dblclick();
});

// Click with Modifiers : press Shift key press during click : cy.shiftClick('selector');
Cypress.Commands.add("shiftClick", (selector) => {
  cy.get(selector).click({ shiftKey: true });
});

// Click with Modifiers : press Control key press during click : cy.controlClick('selector');
Cypress.Commands.add("ctlrClick", (selector) => {
  cy.get(selector).click({ ctrlKey: true });
});

// Click with Modifiers : press Control alt press during click : cy.altClick('selector');
Cypress.Commands.add("altClick", (selector) => {
  cy.get(selector).click({ altKey: true });
});

// Clicking Using Coordinates : cy.clickByCoordinates('selector', x,y);
Cypress.Commands.add("clickByCoordinates", (selector, x, y) => {
  cy.get(selector).click(x, y);
});

// Utility method to select an option from a dropdown : cy.selectDropdown('locator', 'text')
Cypress.Commands.add("selectDropdown", (dropdownSelector, optionValue) => {
  cy.get(dropdownSelector)
    .select(optionValue)
    .should("have.value", optionValue);
});

// Utility method to select a dropdown option by visible text :  cy.selectDropdownByText('locator', 'text')
Cypress.Commands.add("selectDropdownByText", (dropdownSelector, optionText) => {
  cy.get(dropdownSelector).select(optionText).should("contain", optionText);
});

// Utility method to select a dropdown option by index :  cy.selectDropdownByIndex('locator', 0);
Cypress.Commands.add(
  "selectDropdownByIndex",
  (dropdownSelector, optionIndex) => {
    cy.get(dropdownSelector)
      .children("option")
      .eq(optionIndex)
      .then((option) => {
        const optionValue = option.val();
        cy.get(dropdownSelector)
          .select(optionValue)
          .should("have.value", optionValue);
      });
  }
);

/* Utility method to get text from an element : cy.getText('locator') |
                                                cy.getText('.example-class', { trim: false })
                                                */
Cypress.Commands.add("getText", (selector, options = {}) => {
  const { trim = true } = options;

  cy.get(selector) // Locate the element
    .should("be.visible") // Ensure the element is visible
    .then(($el) => {
      let text = $el.text().trim(); // Get the text content and trim it by default
      if (!trim) {
        text = $el.text(); // If 'trim' is false, return the text as-is
      }
      return text;
    });
});

Cypress.Commands.add("getCurrentUrl", () => {
  return cy.url();
});

Cypress.Commands.add("refreshPage", () => {
  cy.reload();
});

Cypress.Commands.add("mouseoverElement", (selector) => {
  cy.get(selector).trigger("mouseover");
});

Cypress.Commands.add("isEnabled", (selector) => {
  cy.get(selector).should("not.be.disabled");
});

Cypress.Commands.add("isDisabled", (selector) => {
  cy.get(selector).should("be.disabled");
});

Cypress.Commands.add("isDisplayed", (selector) => {
  cy.get(selector).should("be.visible");
});

Cypress.Commands.add("isSelected", (selector) => {
  cy.get(selector).should("be.checked");
});

Cypress.Commands.add("waitUntilElementSupress", (selector, timeout = 6000) => {
  cy.get(selector, { timeout }).should("not.exist");
});

Cypress.Commands.add("dragAndDrop", (sourceSelector, targetSelector) => {
  cy.get(sourceSelector).trigger("mousedown", { which: 1 });

  cy.get(targetSelector)
    .trigger("mousemove")
    .trigger("mouseup", { force: true });
});

Cypress.Commands.add("handleDialog", {
  // use : cy.handleDialog.alert('Expected alert message');
  alert: (expectedText) => {
    cy.on("window:alert", (alertText) => {
      expect(alertText).to.include(expectedText);
      return true;
    });
  },

  // cy.handleDialog.confirm('expectedText', true/false);
  confirm: (expectedText, accept = true) => {
    cy.on("window:confirm", (confirmText) => {
      expect(confirmText).to.include(expectedText);
      return accept; // accept or dismiss
    });
  },

  // use : cy.handleDialog.prompt('expectedText', 'promptText', true/false);
  prompt: (expectedText, promptText = "", accept = true) => {
    cy.on("window:prompt", (promptMessage) => {
      expect(promptMessage).to.include(expectedText);
      return accept ? promptText : null;
    });
  },
});
