// Method to make a GET request
Cypress.Commands.add('getRequest', (url, headers = {}) => {
    return cy.request({
        method: "GET",
        url,
        headers,
        failOnStatusCode: false,
    }).then((response) => {
        return cy.wrap(response);
      });
});

// Method to make a POST request
Cypress.Commands.add('postRequest', (url, body, headers = {}) => {
    return cy.request({
        method: "POST",
        url,
        body,
        headers,
        failOnStatusCode: false,
    }).then((response) => {
        return cy.wrap(response);
      });
});

// Method to make an authenticated GET request
Cypress.Commands.add('getRequestWithAuth', (url, token) => {
    return cy.request({
        method: "GET",
        url,
        headers: {
            Authorization: `Bearer ${token}`,
        },
        failOnStatusCode: false,
    }).then((response) => {
        return cy.wrap(response);
      });
});

// Method to make an authenticated POST request
Cypress.Commands.add('postRequestWithAuth', (url, body, token) => {
    return cy.request({
        method: "POST",
        url,
        body,
        headers: {
            Authorization: `Bearer ${token}`,
        },
        failOnStatusCode: false,
    }).then((response) => {
        return cy.wrap(response);
      });
});

// Assertion for checking status code
export const checkStatusCode = (response, expectedStatusCode) => {
    expect(response.status).to.eq(expectedStatusCode);
};

Cypress.Commands.add('checkStatusCode', (response, expectedStatusCode) => {
    expect(response.status).to.eq(expectedStatusCode);
})

// Assertion for checking if a response body contains a certain property
Cypress.Commands.add('checkResponseBodyProperty', (response, propertyName) => {
    expect(response).to.have.property(propertyName);
});

// Assertion for checking if a response body contains a certain property and its value
Cypress.Commands.add('checkResponseBodyPropertyValue', (response, propertyName, propertyValue) => {
    cy.wrap(response).should('have.property', propertyName, propertyValue);
});

Cypress.Commands.add('checkResponseBodyNotEmpty', (response) => {
    expect(response.body).to.not.be.empty;
});