class generateAccessToken {
  getAccessToken(mid, key) {
    const headers = {
      "Merchant-API-Key-Id": mid,
      "Merchant-API-Key-Secret": key,
    };

    const body = {};

    return cy.postRequest(
      Cypress.env("url") + "transaction/v1/token/access",
      body,
      headers
    );
  }

  toExpireToken(token) {
    const body = {};

    return cy.postRequestWithAuth(
      Cypress.env("url") + "transaction/v1/token/invalidate",
      body,
      token
    );
  }
}

export default new generateAccessToken();
