class getCustomer {
  getUserData(token, custID) {
    return cy.getRequestWithAuth(Cypress.env("url") + "transaction/v1/customer/" + custID,
      token
    );
  }

  getUserDataForInvalidEndPoint(token, endpoint, custID) {
    return cy.getRequestWithAuth(Cypress.env("url") + endpoint + custID,
      token
    );
  }
}

export default new getCustomer();
