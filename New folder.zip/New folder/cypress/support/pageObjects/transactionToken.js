class transactionToken {
  getTransactionToken(mid, key, hash) {
    const headers = {
      "Merchant-API-Key-Id": mid,
      "Merchant-API-Key-Secret": key,
    };

    const body = {};

    return cy.postRequest(
      Cypress.env("url") + "transaction/v1/token/transaction/"+ hash,
      body,
      headers
    );
  }
}

export default new transactionToken();
