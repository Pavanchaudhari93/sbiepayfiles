// cypress/support/hooks.js
const dayjs = require("dayjs");

const runInfos = "";
let startTime;
let endTime;
let duration1;

before(() => {
  startTime = dayjs(runInfos["startedTestsAt"]).format("YYYY-MM-DD HH:mm:ss.SSS"
  );

  cy.readFile("cypress/support/executionTime.json").then((data) => {
    data.startTime = startTime;
    cy.writeFile("cypress/support/executionTime.json", data);
  });
});

after(() => {
    endTime = dayjs(runInfos["endedTestsAt"]).format("YYYY-MM-DD HH:mm:ss.SSS"),
    cy.readFile("cypress/support/executionTime.json").then((data) => {
      data.endTime = endTime;
      cy.writeFile("cypress/support/executionTime.json", data);
    });

  // const date1 = dayjs(startTime, "YYYY-MM-DD HH:mm:ss.SSS");
  // const date2 = dayjs(endTime, "YYYY-MM-DD HH:mm:ss.SSS");

  // const diffInSeconds = Math.floor((date2.diff(date1)) / (1000));
  // const diffInMinutes = Math.floor((date2.diff(date1)) / (1000 * 60));
  // const diffInHours = Math.floor((date2.diff(date1)) / (1000 * 60 * 60));

  // duration1=diffInHours+'h:'+diffInMinutes+'m:'+diffInSeconds+'s:'+diffInMilliseconds+'ms'
  //   cy.readFile("cypress/support/executionTime.json").then((data) => {
  //       data.duration = duration1;
  //       cy.writeFile("cypress/support/executionTime.json", data);
  //     });
});

