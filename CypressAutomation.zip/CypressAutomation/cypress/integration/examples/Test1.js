// cypress - spec(test file)
import "cypress-xpath";
import "cypress-iframe";

describe("Assertion, type, alisas, each loop", function () {
    it("My first Test case", function () {
        //test steps
        cy.visit("https://rahulshettyacademy.com/seleniumPractise/#/");
        cy.xpath('//input[@type="search"]').type("ca");
        cy.wait(2000);
        // cy.xpath('//div[@class="product"]').should('have.length', 4)
        // cy.get('.product:visible').should('have.length', 4)
        cy.get(".products").find(".product").should("have.length", 4);
        //  cy.contains('ADD TO CART')  //get first ADD TO CARD
        cy.get(".products").as("productContainer");
        cy.get("@productContainer")
            .find(".product")
            .eq(2)
            .contains("ADD TO CART")
            .click();

        cy.get(".products")
            .find(".product")
            .each(($el, index, $list) => {
                const textVeg = $el.find("h4.product-name").text();
                if (textVeg.includes("Cashews")) {
                    cy.wrap($el).find("button").click();
                }
            });
        cy.get(".brand.greenLogo").should("have.text", "GREENKART");
        cy.get(".brand.greenLogo").then(function (logoelement) {
            cy.log(logoelement.text());
            console.log(logoelement.text());
        });

        /* const logo = cy.get('.brand.greenLogo')
             cy.get('.brand.greenLogo').text()*/
    });

    it("static dropdown", function () {
        //checkbox
        cy.visit("https://rahulshettyacademy.com/AutomationPractice/");
        cy.xpath('//input[@id="checkBoxOption1"]')
            .click()
            .should("be.checked")
            .and("have.value", "option1");
        cy.get('input[type="checkbox"]').check(["option1", "option2", "option3"]);

        //static dropdown
        cy.get("select").select("option3").should("have.value", "option3");
    });

    it("Dynamic dropdown", function () {
        // dynamic dropdown
        cy.get("#autocomplete").type("Ind");
        cy.get(".ui-menu-item div").each(($e1, index, $list) => {
            if ($e1.text() === "India") {
                $e1.click();
            }
        });
        cy.get("#autocomplete").should("have.value", "India");
    });

    it("Alert and popups", function () {
        //ALERT/ POPUP
        cy.visit("https://rahulshettyacademy.com/AutomationPractice/");
        cy.get("#alertbtn").click();

        cy.get("#confirmbtn").click();
        cy.on("window:alert", (str) => {
            expect(str).to.equal(
                "Hello , share this practice page and share your knowledge"
            );
        });
        cy.on("window:confirm", (str) => {
            expect(str).to.equal("Hello , Are you sure you want to confirm?");
        });
    });

    it("handle chiled tab", function () {
        cy.visit("https://rahulshettyacademy.com/AutomationPractice/");
        cy.get("#opentab").invoke("removeAttr", "target").click();

        cy.origin("https://www.qaclickacademy.com", () => {
            cy.get('#navbarSupportedContent a[href*="about"]').click();
            cy.get(".mt-50 h2").should("contain", "Welcome to QAClick Academy");
        });
    });

    it("handle web table", function () {
        cy.visit("https://rahulshettyacademy.com/AutomationPractice/");

        cy.get("tr td:nth-child(2)").each(($e1, index, $list) => {
            const text = $e1.text();
            if (text.includes("Python")) {
                cy.get("tr td:nth-child(2)")
                    .eq(index)
                    .next()
                    .then(function (price) {
                        const priceText = price.text();
                        expect(priceText).to.equal("25");
                    });
            }
        });
    });

    it("mouse hover", function () {
        cy.visit("https://rahulshettyacademy.com/AutomationPractice/");
        // cy.get('div.mouse-hover-content').invoke('show')
        // cy.contains('Top').click();

        cy.contains("Top").click({ force: true });
        cy.url().should("include", "top");
    });

    it("Handle frames", function () {
        cy.visit("https://rahulshettyacademy.com/AutomationPractice/");
        cy.frameLoaded("#courses-iframe");
        cy.iframe().find("a[href*='mentorship']").eq(0).click();
    });

    it.only("Verify date selection", () => {
        const monthNumber = "6";
        const date = "15";
        const year = "2027";
        const expectedList = [monthNumber, date, year];

        cy.visit("https://rahulshettyacademy.com/seleniumPractise/#/offers");
        cy.wait(2000);
        cy.get(".react-date-picker__inputGroup").click();

        cy.get(".react-calendar__navigation__label").click();
        cy.get(".react-calendar__navigation__label").click();
        cy.contains("button", year).click();
        cy.get(".react-calendar__year-view__months__month")
            .eq(Number(monthNumber) - 1)
            .click();
        cy.contains("abbr", date).click();

        //Assertion
        cy.get(".react-date-picker__inputGroup__input").each(($el, index) => {
            cy.wrap($el).invoke("val").should("eq", expectedList[index]);
        });
    });
});